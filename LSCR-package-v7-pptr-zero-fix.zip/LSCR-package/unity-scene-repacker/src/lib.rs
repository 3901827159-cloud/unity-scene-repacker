mod batched_cache;
mod merge_serialized;
pub mod monobehaviour_typetree_export;

pub use rabex;
use rabex::objects::ClassId;
use rabex_env::Environment;
use rabex_env::env::Data;
use rabex_env::handle::SerializedFileHandle;
use rabex_env::resolver::{EnvResolver as _, GameFiles};
use rabex_env::scene_lookup::SceneLookup;
use rabex_env::unity::types::{AssetBundle, AssetInfo, MonoBehaviour, PreloadData, Transform};

use anyhow::{Context, Result};
use indexmap::{IndexMap, IndexSet};
use log::warn;
use rabex::UnityVersion;
use rabex::files::bundlefile::{BundleFileBuilder, CompressionType};
use rabex::files::serializedfile::FileIdentifier;
use rabex::files::serializedfile::builder::SerializedFileBuilder;
use rabex::files::{SerializedFile, serializedfile};
use rabex::objects::pptr::{FileId, PPtr, PathId};
use rabex::tpk::TpkTypeTreeBlob;
use rabex::typetree::{TypeTreeNode, TypeTreeProvider};
use rayon::iter::{IntoParallelIterator, IntoParallelRefIterator, ParallelIterator};
use rustc_hash::{FxHashMap, FxHashSet};
use std::borrow::Cow;
use std::collections::BTreeSet;
use std::fmt::Debug;
use std::io::{Cursor, Read, Seek, Write};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};

pub struct RepackSettings {
    pub scene_objects: IndexMap<String, Vec<String>>,
    pub extra_objects: IndexMap<String, IndexSet<String>>,
}
impl RepackSettings {
    pub fn is_empty(&self) -> bool {
        self.scene_objects.is_empty() && self.extra_objects.is_empty()
    }
}

pub struct RepackScene<'a> {
    pub original_name: PathBuf,
    pub scene_name: String,

    pub serialized: SerializedFile,
    pub serialized_data: Data,

    pub keep_objects: BTreeSet<i64>,
    pub roots: Vec<(String, Transform)>,
    pub replacements: FxHashMap<PathId, Vec<u8>>,

    pub monobehaviour_types: FxHashMap<i64, &'a TypeTreeNode>,
}

// Filename, PathId, Classname, Objectname
type ExtraObject = (PathBuf, PathId, String, String);

pub fn repack_scenes<'a>(
    env: &'a Environment,
    repack_settings: RepackSettings,
    prepare_scripts: bool,
    disable_roots: bool,
) -> Result<(Vec<RepackScene<'a>>, Vec<ExtraObject>)> {
    let (scenes, extra_objects) = collect_what_to_repack(
        env,
        &repack_settings,
        |filename, scene_name, object_paths, file, data| {
            let settings = RepackSceneSettings {
                object_paths,
                disable_roots,
            };
            repack_scene(
                env,
                prepare_scripts,
                filename,
                scene_name,
                settings,
                file,
                data,
            )
        },
    )?;

    for (class_name, names) in repack_settings.extra_objects {
        for name in names {
            let found = extra_objects
                .iter()
                .any(|(_, _, found_class_name, found_name)| {
                    class_name == *found_class_name && name == *found_name
                });
            if !found {
                warn!("Did not found {class_name} named '{name}' in game files");
            }
        }
    }

    Ok((scenes, extra_objects))
}

// TODO: this is a mess, refactor it away
fn collect_what_to_repack<T: Send + Sync>(
    env: &Environment,
    repack_settings: &RepackSettings,
    // |filename, scene_name, object_paths, file, data|
    f: impl Fn(&Path, &str, &[String], SerializedFile, Data) -> Result<T> + Send + Sync,
) -> Result<(Vec<T>, Vec<ExtraObject>)> {
    let build_settings = env.build_settings()?;
    let has_extra_objects = !repack_settings.extra_objects.is_empty();

    let read = |filename: &Path, scene_name| -> Result<_> {
        let data = env.game_files.read_path(filename).with_context(|| {
            format!(
                "{} does not exist in game files",
                scene_name_display(scene_name, filename)
            )
        })?;

        let mut reader = Cursor::new(data.as_ref());
        let file = SerializedFile::from_reader(&mut reader).with_context(|| {
            format!(
                "Could not parse {}",
                scene_name_display(scene_name, filename)
            )
        })?;

        Ok((data, file))
    };

    // if we have extra monobehaviour to collect, we have to look at every possible file
    let (extra_objects, scenes) = if has_extra_objects {
        let scene_lookup: Vec<_> = build_settings.scene_names().collect();

        env.game_files
            .serialized_files()?
            .into_par_iter()
            .map(|filename| -> Result<_> {
                let (data, file_raw) = read(&filename, None)?;
                let file = SerializedFileHandle::new(env, &file_raw, data.as_ref());

                let extra_objects =
                    find_extra_objects(file, &filename, &repack_settings.extra_objects)?;

                if let Some(scene_index) = filename
                    .to_str()
                    .and_then(|name| name.strip_prefix("level"))
                    .and_then(|x| x.parse::<usize>().ok())
                {
                    let scene_name = scene_lookup[scene_index];

                    if let Some(object_paths) = repack_settings.scene_objects.get(scene_name) {
                        let x = f(&filename, scene_name, object_paths, file_raw, data)?;
                        return Ok((extra_objects, Some(x)));
                    }
                }

                Ok((extra_objects, None))
            })
            .try_fold(
                || (Vec::new(), Vec::new()),
                |mut acc, item| -> Result<_> {
                    let item = item?;
                    acc.0.extend(item.0);
                    if let Some(scene) = item.1 {
                        acc.1.push(scene);
                    }
                    Ok(acc)
                },
            )
            .try_reduce(
                || (Vec::new(), Vec::new()),
                |mut acc, item| {
                    acc.0.extend(item.0);
                    acc.1.extend(item.1);
                    Ok(acc)
                },
            )?
    } else {
        let scene_lookup = build_settings.scene_name_lookup();

        let scene_files = repack_settings
            .scene_objects
            .iter()
            .map(|(scene_name, object_paths)| {
                let scene_index = *scene_lookup.get(scene_name).with_context(|| {
                    let scene_names = scene_lookup
                        .keys()
                        .map(String::as_str)
                        .collect::<Vec<_>>()
                        .join("\n-  ");
                    format!(
                        "Scene '{scene_name}' was not found in game files.\nFound\n- {}",
                        scene_names
                    )
                })?;
                let filename = format!("level{scene_index}");
                Ok((scene_name, PathBuf::from(filename), object_paths.as_slice()))
            })
            .collect::<Result<Vec<_>>>()?;

        let scenes = scene_files
            .par_iter()
            .map(|(scene_name, filename, object_paths)| -> Result<_> {
                let (data, file) = read(filename, None)?;
                f(filename, scene_name, object_paths, file, data)
            })
            .collect::<Result<Vec<_>>>()?;
        (Vec::new(), scenes)
    };

    Ok((scenes, extra_objects))
}

struct RepackSceneSettings<'a> {
    object_paths: &'a [String],
    disable_roots: bool,
}

fn repack_scene<'a>(
    env: &'a Environment,
    prepare_scripts: bool,
    original_name: &Path,
    scene_name: &str,
    settings: RepackSceneSettings,
    file: SerializedFile,
    serialized_data: Data,
) -> Result<RepackScene<'a>> {
    let reader = &mut Cursor::new(serialized_data.as_ref());

    let scene_paths = deduplicate_objects(original_name, scene_name, settings.object_paths);

    let mut replacements = FxHashMap::default();
    let result = rabex_env::reachable::prune::prune_scene(
        env,
        &file,
        reader,
        scene_paths.iter().copied(),
        &mut replacements,
        settings.disable_roots,
    )
    .with_context(|| scene_name_display(scene_name, original_name))?;

    let monobehaviour_types = prepare_scripts
        .then(|| prepare_monobehaviour_types(env, &file, reader))
        .unwrap_or_default();

    Ok(RepackScene {
        original_name: original_name.to_owned(),
        scene_name: scene_name.to_owned(),
        serialized: file,
        serialized_data,
        keep_objects: result.reachable,
        roots: result.roots,
        replacements,
        monobehaviour_types,
    })
}

fn find_extra_objects(
    file: SerializedFileHandle<GameFiles, impl TypeTreeProvider>,
    filename: &Path,
    // classname: [objectname]
    extra_objects: &IndexMap<String, IndexSet<String>>,
) -> Result<Vec<(PathBuf, PathId, String, String)>, anyhow::Error> {
    let mut roots = Vec::new();

    for mb_obj in file.objects_of::<MonoBehaviour>() {
        let Some(script) = mb_obj.mono_script()? else {
            continue;
        };

        let Some(mb_names) = extra_objects.get(&script.m_ClassName) else {
            continue;
        };

        let mb = mb_obj.read()?;
        if mb_names.contains(&mb.m_Name) {
            roots.push((
                filename.to_owned(),
                mb_obj.path_id(),
                script.m_ClassName,
                mb.m_Name,
            ));
        }
    }
    Ok(roots)
}

fn scene_name_display<'a>(scene_name: impl Into<Option<&'a str>>, original_name: &Path) -> String {
    match scene_name.into() {
        Some(scene_name) => format!("{scene_name} ({})'", original_name.display()),
        None => format!("'{}'", original_name.display()),
    }
}

fn prune_types(file: &mut SerializedFile) -> FxHashMap<i32, i32> {
    let used_types: FxHashSet<_> = file.objects().map(|obj| obj.m_TypeID).collect();
    let mut old_to_new: FxHashMap<i32, i32> = FxHashMap::default();
    file.m_Types = std::mem::take(&mut file.m_Types)
        .into_iter()
        .enumerate()
        .filter(|&(idx, _)| used_types.contains(&(idx as i32)))
        .enumerate()
        .map(|(new_index, (old_index, ty))| {
            old_to_new.insert(old_index as i32, new_index as i32);
            ty
        })
        .collect();
    old_to_new
}

fn deduplicate_objects<'a>(
    original_name: &Path,
    scene_name: &str,
    paths: &'a [String],
) -> IndexSet<&'a str> {
    let mut deduplicated = IndexSet::new();
    for item in paths {
        if !deduplicated.insert(item.as_str()) {
            warn!(
                "Duplicate object: '{item}' in {}",
                scene_name_display(Some(scene_name), original_name)
            );
        }
    }
    deduplicated
}

#[derive(Debug, Default)]
pub struct Stats {
    pub objects_before: usize,
    pub objects_after: usize,
    pub size_before: usize,
    pub size_after: usize,
}

pub fn pack_to_scene_bundle(
    writer: impl Write + Seek,
    bundle_name: &str,
    tpk_blob: &TpkTypeTreeBlob,
    tpk: &impl TypeTreeProvider,
    unity_version: &UnityVersion,
    scenes: &mut [RepackScene],
    compression: CompressionType,
) -> Result<Stats> {
    let mut stats = Stats::default();
    let common_offset_map = serializedfile::build_common_offset_map(tpk_blob, unity_version);

    let mut asset_bundle = AssetBundle::scene_base(bundle_name);
    for scene in &*scenes {
        let scene_name = &scene.scene_name;
        let scene_hash = get_scene_bundle_filename(bundle_name, scene_name);
        let path = get_scene_bundle_scene_name(bundle_name, scene_name);
        asset_bundle.add_scene(&path, &scene_hash);
    }

    let mut asset_bundle = Some(asset_bundle);

    let mut builder = BundleFileBuilder::unityfs(7, unity_version);
    for scene in scenes {
        let mut sharedassets =
            SerializedFileBuilder::new(unity_version, tpk, &common_offset_map, true);

        sharedassets.add_object_at(1, &PreloadData::default())?;

        if let Some(asset_bundle) = asset_bundle.take() {
            sharedassets.add_object_at(2, &asset_bundle)?;
        }

        let mut out = Cursor::new(Vec::new());
        sharedassets.write(&mut out)?;

        let scene_hash = get_scene_bundle_filename(bundle_name, &scene.scene_name);
        builder.add_file(
            &format!("{scene_hash}.sharedAssets",),
            Cursor::new(out.into_inner()),
        )?;

        let trimmed = {
            let serialized = &mut scene.serialized;

            let data = scene.serialized_data.as_ref();

            stats.objects_before += serialized.objects().len();
            stats.size_before += data.len();

            serialized.modify_objects(|objects| {
                objects.retain(|obj| scene.keep_objects.contains(&obj.m_PathID));
            });
            stats.objects_after += serialized.objects().len();

            let type_remap = prune_types(serialized);

            let new_objects = serialized.take_objects();
            let objects = new_objects.into_iter().map(|mut obj| {
                let data = match scene.replacements.remove(&obj.m_PathID) {
                    Some(owned) => Cow::Owned(owned),
                    None => {
                        let offset = obj.m_Offset as usize;
                        let size = obj.m_Size as usize;
                        Cow::Borrowed(&data[offset..offset + size])
                    }
                };

                obj.m_TypeID = type_remap[&obj.m_TypeID];

                (obj, data)
            });

            let mut writer = Cursor::new(Vec::new());
            serializedfile::write_serialized_with_objects(
                &mut writer,
                serialized,
                &common_offset_map,
                objects,
            )?;
            let out = writer.into_inner();

            stats.objects_after += serialized.objects().len();
            stats.size_after += out.len();

            out
        };
        builder.add_file(&scene_hash, Cursor::new(trimmed))?;
    }

    builder.write(writer, compression)?;

    Ok(stats)
}

pub enum MonobehaviourTypetreeMode<'a> {
    GenerateRuntime,
    Export(&'a [u8]),
}

pub fn pack_to_asset_bundle(
    env: &Environment,
    writer: impl Write + Seek,
    bundle_name: &str,
    tpk_blob: &TpkTypeTreeBlob,
    scenes: Vec<RepackScene>,
    extra_objects: Vec<ExtraObject>,
    compression: CompressionType,
    enable_typetree: bool,
) -> Result<Stats> {
    let unity_version = env.unity_version()?;
    let common_offset_map = serializedfile::build_common_offset_map(tpk_blob, unity_version);
    let mut stats = Stats::default();

    let mut builder =
        SerializedFileBuilder::new(unity_version, &env.tpk, &common_offset_map, enable_typetree);
    builder.next_path_id = 2;

    let mut asset_bundle = AssetBundle::asset_base(bundle_name);
    for (filename, path_id, class_name, object_name) in extra_objects {
        // TODO cached
        let file_id = builder.add_external_uncached(FileIdentifier::try_from(filename)?);
        let info = AssetInfo::new(PPtr::new(file_id, path_id));
        asset_bundle
            .m_Container
            .insert(get_extra_object_asset_name(&class_name, &object_name), info);
    }

    let intermediate = scenes
        .into_iter()
        .map(|mut scene| {
            let serialized = &mut scene.serialized;
            let data = scene.serialized_data.as_ref();

            assert_eq!(serialized.m_bigIDEnabled, None);
            if let Some(ref_types) = &serialized.m_RefTypes
                && !ref_types.is_empty()
            {
                warn!(
                    "Found {} m_RefTypes in scene {}, this is untested.",
                    ref_types.len(),
                    scene.scene_name
                );
            }

            stats.objects_before += serialized.objects().len();
            stats.size_before += data.len();
            serialized.modify_objects(|objects| {
                objects.retain(|obj| scene.keep_objects.contains(&obj.m_PathID))
            });
            stats.objects_after += serialized.objects().len();

            let remap = merge_serialized::add_scene_meta_to_builder(&mut builder, serialized)?;

            if builder.serialized.m_EnableTypeTree {
                for ty in &mut builder.serialized.m_Types {
                    if ty.m_Type.is_none() {
                        if ty.m_ClassID == ClassId::MonoBehaviour {
                            log::warn!(
                                "Asset bundle is to be serialized with type tree information, "
                            );
                            log::warn!("but the repack sources don't contain any.");
                            log::warn!(
                                "Monobehaviours typetrees will not contain serialized fields."
                            );
                        }
                        ty.m_Type = Some(
                            env.tpk
                                .get_typetree_node(ty.m_ClassID, unity_version)
                                .ok_or(serializedfile::Error::NoTypetree(ty.m_ClassID))?
                                .into_owned(),
                        );
                    }
                }
            }

            for (scene_path, transform) in scene.roots.iter() {
                let mut go = transform.m_GameObject;
                assert!(go.is_local());
                if let Some(replacement) = remap.path_id.get(&go.m_PathID) {
                    go.m_PathID = *replacement;
                }

                let info = AssetInfo::new(go.untyped());
                let path = get_asset_bundle_object_asset_name(&scene.scene_name, scene_path);

                asset_bundle.m_Container.insert(path, info);
            }

            Ok((scene, remap))
        })
        .collect::<Result<Vec<_>>>()?;

    let objects = intermediate
        .into_par_iter()
        .map(|(mut scene, remap)| {
            merge_serialized::remap_objects(
                &scene.scene_name,
                scene.original_name,
                &builder.serialized,
                scene.serialized_data.as_ref(),
                &env.tpk,
                scene.serialized.take_objects(),
                scene.replacements,
                scene.monobehaviour_types,
                remap,
            )
            .collect::<Vec<_>>()
        })
        .collect::<Vec<Vec<Result<_>>>>();

    objects.into_iter().try_for_each(|objects| -> Result<_> {
        for obj in objects {
            let (obj, data) = obj?;
            builder.objects.insert(obj.m_PathID, (obj, data));
        }
        Ok(())
    })?;

    builder.add_object_at(1, &asset_bundle)?;

    let mut out = Vec::new();
    builder.write(&mut Cursor::new(&mut out))?;
    stats.size_after += out.len();

    let mut bundle_builder = BundleFileBuilder::unityfs(7, unity_version);
    bundle_builder.add_file(&format!("CAB-{bundle_name}"), Cursor::new(out))?;

    bundle_builder.write(writer, compression)?;

    Ok(stats)
}

#[inline(never)]
fn prepare_monobehaviour_types<'a>(
    env: &'a Environment,
    file: &SerializedFile,
    reader: &mut (impl Read + Seek),
) -> FxHashMap<PathId, &'a TypeTreeNode> {
    file.objects_of::<MonoBehaviour>(&env.tpk)
        .map(|mb_info| -> Result<_> {
            let path_id = mb_info.info.m_PathID;

            let mb = mb_info.read(reader)?;
            if mb.m_Script.is_null() {
                return Ok(None);
            }
            let script = env
                .deref_read(mb.m_Script, file, reader)
                .with_context(|| format!("In monobehaviour {}", mb_info.info.m_PathID))?;

            let assembly_name = script.assembly_name();
            let full_name = script.full_name();

            let ty = &file.m_Types[mb_info.info.m_TypeID as usize];
            if let Some(ty) = &ty.m_Type {
                // TODO: check if there is actually more than default information present
                let ty =
                    env.typetree_generator
                        .insert_cache(&assembly_name, &full_name, ty.clone());
                return Ok(Some((path_id, ty)));
            }

            let ty = env
                .generate_typetree(&assembly_name, &full_name)
                .with_context(|| {
                    format!("Reading script {assembly_name} {full_name} at object {path_id}",)
                })?;
            let Some(ty) = ty else { return Ok(None) };

            Ok(Some((path_id, ty)))
        })
        .filter_map(|x| x.transpose())
        .filter_map(|ty| match ty {
            Ok(val) => Some(val),
            Err(e) => {
                log::error!("{e:?}");
                None
            }
        })
        .collect::<FxHashMap<_, _>>()
}

pub fn pack_to_shallow_asset_bundle(
    env: &Environment,
    writer: impl Write + Seek,
    bundle_name: &str,
    repack_settings: RepackSettings,
    compression: CompressionType,
) -> Result<Stats> {
    let objects_before = AtomicUsize::new(0);
    let size_before = AtomicUsize::new(0);

    let (scene_objects, extra_objects) = collect_what_to_repack(
        env,
        &repack_settings,
        |filename, scene_name, object_paths, file, data| {
            let object_paths = deduplicate_objects(filename, scene_name, object_paths);

            objects_before.fetch_add(file.objects().len(), Ordering::Relaxed);
            size_before.fetch_add(data.as_ref().len(), Ordering::Relaxed);

            let reader = &mut Cursor::new(data.as_ref());

            let mut path_ids = Vec::with_capacity(object_paths.len());
            let lookup = SceneLookup::new(&file, reader, &env.tpk)?;
            for path in object_paths {
                let Some((_, transform)) = lookup.lookup_path(reader, path)? else {
                    warn!("Could not find path '{path}' in {scene_name}");
                    continue;
                };
                path_ids.push((path.to_owned(), transform.m_GameObject.m_PathID));
            }

            Ok(((scene_name.to_owned(), filename.to_owned()), path_ids))
        },
    )?;

    create_shallow_assetbundle(
        env,
        writer,
        bundle_name,
        scene_objects,
        extra_objects,
        compression,
    )?;

    Ok(Stats {
        objects_before: objects_before.into_inner(),
        objects_after: 0,
        size_before: size_before.into_inner(),
        size_after: 0,
    })
}

fn create_shallow_assetbundle(
    env: &Environment,
    writer: impl Write + Seek,
    bundle_name: &str,
    // (scenename, Filename)
    objects: Vec<((String, PathBuf), Vec<(String, PathId)>)>,
    extra_objects: Vec<ExtraObject>,
    compression: CompressionType,
) -> Result<()> {
    let unity_version = env.unity_version()?;
    let common_offset_map = serializedfile::build_common_offset_map(&env.tpk.inner, unity_version);

    let mut builder =
        SerializedFileBuilder::new(unity_version, &env.tpk, &common_offset_map, false);

    let mut ab = AssetBundle::asset_base(bundle_name);

    for (filename, path_id, class_name, object_name) in extra_objects {
        // TODO cached
        let file_id = builder.add_external_uncached(FileIdentifier::try_from(filename)?);
        let info = AssetInfo::new(PPtr::new(file_id, path_id));
        ab.m_Container
            .insert(get_extra_object_asset_name(&class_name, &object_name), info);
    }

    for ((scene_name, original_name), objects) in objects {
        // TODO: is this right?
        let file_index = builder.add_external_uncached(FileIdentifier::try_from(original_name)?);

        for (scene_path, path_id) in objects {
            let path = get_asset_bundle_object_asset_name(&scene_name, &scene_path);
            let info = AssetInfo::new(PPtr::new(file_index, path_id));
            ab.m_Container.insert(path, info);
        }
    }

    builder.add_object_at(1, &ab)?;

    let mut builder_out = Vec::new();
    builder.write(Cursor::new(&mut builder_out))?;

    let mut bundle = BundleFileBuilder::unityfs(7, unity_version);
    bundle.add_file(&format!("CAB-{bundle_name}"), Cursor::new(builder_out))?;

    bundle.write(writer, compression)?;

    Ok(())
}

// ============================================================
// LSCR Batched Repack API
// ============================================================

pub use batched_cache::{Manifest, SceneMeta};
use batched_cache::{mark_scene_done, mark_scene_failed, read_scene_meta, read_serialized, write_scene_meta, write_serialized, write_manifest, init_manifest};
use batched_cache::intermediate_serialized_path;

/// Trim a single scene and write intermediate files (Phase 1).
pub fn trim_scene_to_file(
    env: &Environment,
    scene_name: &str,
    object_paths: &[String],
    original_name: &Path,
    cache_dir: &Path,
    idx: usize,
    prepare_scripts: bool,
) -> Result<Stats> {
    let data = env.game_files.read_path(original_name).with_context(|| {
        format!("{} does not exist in game files", scene_name_display(scene_name, original_name))
    })?;

    let mut reader = Cursor::new(data.as_ref());
    let file = SerializedFile::from_reader(&mut reader).with_context(|| {
        format!("Could not parse {}", scene_name_display(scene_name, original_name))
    })?;

    let scene_paths = deduplicate_objects(original_name, scene_name, object_paths);

    let mut replacements = FxHashMap::default();
    let result = rabex_env::reachable::prune::prune_scene(
        env,
        &file,
        &mut Cursor::new(data.as_ref()),
        scene_paths.iter().copied(),
        &mut replacements,
        true,
    )
    .with_context(|| scene_name_display(scene_name, original_name))?;

    let monobehaviour_types = prepare_scripts
        .then(|| prepare_monobehaviour_types(env, &file, &mut Cursor::new(data.as_ref())))
        .unwrap_or_default();

    let mut serialized = file;
    let mut stats = Stats::default();
    stats.objects_before += serialized.objects().len();
    stats.size_before += data.as_ref().len();

    serialized.modify_objects(|objects| {
        objects.retain(|obj| result.reachable.contains(&obj.m_PathID));
    });
    stats.objects_after += serialized.objects().len();

    let type_remap = prune_types(&mut serialized);

    let new_objects = serialized.take_objects();
    let objects = new_objects.into_iter().map(|mut obj| {
        let object_data = match replacements.remove(&obj.m_PathID) {
            Some(owned) => Cow::Owned(owned),
            None => {
                let offset = obj.m_Offset as usize;
                let size = obj.m_Size as usize;
                Cow::Borrowed(&data.as_ref()[offset..offset + size])
            }
        };
        obj.m_TypeID = type_remap[&obj.m_TypeID];
        (obj, object_data)
    });

    let mut writer = Cursor::new(Vec::new());
    let common_offset_map = serializedfile::build_common_offset_map(&env.tpk.inner, &env.unity_version()?);
    serializedfile::write_serialized_with_objects(
        &mut writer,
        &serialized,
        &common_offset_map,
        objects,
    )?;
    let trimmed = writer.into_inner();
    stats.size_after += trimmed.len();

    // Write intermediate files
    write_serialized(cache_dir, idx, &trimmed)?;

    let meta = SceneMeta {
        scene_name: scene_name.to_owned(),
        original_name: original_name.to_str().unwrap_or("").to_owned(),
        objects_before: stats.objects_before,
        objects_after: stats.objects_after,
        roots: result.roots.into_iter().map(|(s, t)| (s, t.m_GameObject.m_PathID)).collect(),
        replacements: replacements.into_iter().collect(),
        keep_objects: result.reachable.into_iter().collect(),
    };
    write_scene_meta(cache_dir, idx, &meta)?;

    Ok(stats)
}

/// Repack scenes one by one, writing intermediate files (Phase 1).
/// Sequential processing to avoid OOM on low-memory devices.
pub fn repack_scenes_batched(
    env: &Environment,
    repack_settings: RepackSettings,
    cache_dir: &Path,
    resume: bool,
    prepare_scripts: bool,
) -> Result<Stats> {
    let mut manifest = init_manifest(cache_dir, &repack_settings.scene_objects, resume)?;
    let mut total_stats = Stats::default();

    let build_settings = env.build_settings()?;
    let scene_lookup = build_settings.scene_name_lookup();

    let scene_files: Vec<_> = repack_settings
        .scene_objects
        .iter()
        .map(|(scene_name, object_paths)| {
            let scene_index = *scene_lookup.get(scene_name).ok_or_else(|| {
                anyhow::anyhow!("Scene '{}' not found", scene_name)
            })?;
            let filename = PathBuf::from(format!("level{scene_index}"));
            Ok((scene_name.clone(), filename, object_paths.clone()))
        })
        .collect::<Result<Vec<_>>>()?;

    for (idx, (scene_name, filename, object_paths)) in scene_files.iter().enumerate() {
        let entry = manifest.scenes.get(&scene_name);
        if let Some(e) = entry {
            if e.status == "done" {
                log::info!("[LSCR] Skipping already done scene: {}", scene_name);
                continue;
            }
        }

        log::info!("[LSCR] Processing scene {}/{}: {}", idx + 1, scene_files.len(), scene_name);

        match trim_scene_to_file(
            env,
            &scene_name,
            &object_paths,
            &filename,
            cache_dir,
            idx,
            prepare_scripts,
        ) {
            Ok(stats) => {
                total_stats.objects_before += stats.objects_before;
                total_stats.objects_after += stats.objects_after;
                total_stats.size_before += stats.size_before;
                total_stats.size_after += stats.size_after;
                mark_scene_done(&mut manifest, &scene_name)?;
            }
            Err(e) => {
                log::error!("[LSCR] Scene {} failed: {}", scene_name, e);
                mark_scene_failed(&mut manifest, &scene_name)?;
            }
        }

        // Write manifest after each scene for resume support
        write_manifest(cache_dir, &manifest)?;
    }

    Ok(total_stats)
}

/// Phase 2: Read intermediate files and pack into final AssetBundle.
pub fn pack_to_asset_bundle_from_intermediate(
    env: &Environment,
    writer: impl Write + Seek,
    bundle_name: &str,
    repack_settings: &RepackSettings,
    cache_dir: &Path,
    compression: CompressionType,
    enable_typetree: bool,
) -> Result<Stats> {
    let unity_version = env.unity_version()?;
    let common_offset_map = serializedfile::build_common_offset_map(&env.tpk.inner, unity_version);
    let mut stats = Stats::default();

    let mut builder =
        SerializedFileBuilder::new(unity_version, &env.tpk, &common_offset_map, enable_typetree);
    builder.next_path_id = 2;

    let mut asset_bundle = AssetBundle::asset_base(bundle_name);

    let manifest = batched_cache::read_manifest(cache_dir)?;

    let mut done_scenes: Vec<(String, usize)> = Vec::new();
    for (scene_name, entry) in &manifest.scenes {
        if entry.status == "done" {
            done_scenes.push((scene_name.clone(), entry.idx));
        }
    }
    done_scenes.sort_by_key(|(_, idx)| *idx);

    for (scene_name, idx) in done_scenes {
        let meta = read_scene_meta(cache_dir, idx)?;
        let serialized_data = read_serialized(cache_dir, idx)?;

        let mut reader = Cursor::new(&serialized_data);
        let mut file = SerializedFile::from_reader(&mut reader)?;

        stats.objects_before += meta.objects_before;
        stats.size_before += serialized_data.len();
        stats.objects_after += meta.objects_after;

        let remap = merge_serialized::add_scene_meta_to_builder(&mut builder, &mut file)?;

        if builder.serialized.m_EnableTypeTree {
            for ty in &mut builder.serialized.m_Types {
                if ty.m_Type.is_none() {
                    if ty.m_ClassID == ClassId::MonoBehaviour {
                        log::warn!("Asset bundle is to be serialized with type tree information,");
                        log::warn!("but the repack sources don't contain any.");
                        log::warn!("Monobehaviours typetrees will not contain serialized fields.");
                    }
                    ty.m_Type = Some(
                        env.tpk
                            .get_typetree_node(ty.m_ClassID, unity_version)
                            .ok_or(serializedfile::Error::NoTypetree(ty.m_ClassID))?
                            .into_owned(),
                    );
                }
            }
        }

        for (scene_path, path_id_val) in &meta.roots {
            let mut go = rabex::objects::pptr::PPtr::new(
                rabex::objects::pptr::FileId::from_externals_index(0),
                rabex::objects::pptr::PathId(*path_id_val),
            );
            if let Some(replacement) = remap.path_id.get(&go.m_PathID) {
                go.m_PathID = *replacement;
            }

            let info = AssetInfo::new(go.untyped());
            let path = get_asset_bundle_object_asset_name(&meta.scene_name, scene_path);
            asset_bundle.m_Container.insert(path, info);
        }

        let mut replacements_map: FxHashMap<PathId, Vec<u8>> = meta
            .replacements
            .into_iter()
            .map(|(k, v)| (PathId(k), v))
            .collect();

        let objects = merge_serialized::remap_objects(
            &meta.scene_name,
            PathBuf::from(&meta.original_name),
            &builder.serialized,
            &serialized_data,
            &env.tpk,
            file.take_objects(),
            replacements_map,
            FxHashMap::default(), // mb_types: skip for now (rebuild from file typetree)
            remap,
        )
        .collect::<Vec<_>>();

        for obj in objects {
            let (obj, data) = obj?;
            builder.objects.insert(obj.m_PathID, (obj, data));
        }
    }

    builder.add_object_at(1, &asset_bundle)?;

    let mut out = Vec::new();
    builder.write(&mut Cursor::new(&mut out))?;
    stats.size_after += out.len();

    let mut bundle_builder = BundleFileBuilder::unityfs(7, unity_version);
    bundle_builder.add_file(&format!("CAB-{bundle_name}"), Cursor::new(out))?;

    bundle_builder.write(writer, compression)?;

    Ok(stats)
}

fn get_scene_bundle_filename(bundle_name: &str, scene_name: &str) -> String {
    format!("BuildPlayer-{bundle_name}_{scene_name}")
}

fn get_scene_bundle_scene_name(bundle_name: &str, scene_name: &str) -> String {
    format!("Assets/unity-scene-repacker/{bundle_name}_{scene_name}.unity")
}
fn get_asset_bundle_object_asset_name(scene_name: &str, scene_path: &str) -> String {
    format!("{scene_name}/{scene_path}.prefab").to_lowercase()
}
fn get_extra_object_asset_name(class_name: &str, object_name: &str) -> String {
    format!("ExtraObjects/{class_name}/{object_name}.prefab").to_lowercase()
}
