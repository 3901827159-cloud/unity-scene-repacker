use std::collections::HashMap;
use std::fs::{self, File};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};

use anyhow::{Context, Result};
use indexmap::IndexMap;
use serde::{Deserialize, Serialize};

/// manifest.json 结构
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Manifest {
    pub version: u32,
    pub mode: String,
    pub bundle_name: String,
    pub scenes: HashMap<String, SceneEntry>,
    pub failed: Vec<String>,
    pub final_bundle: String,
    pub stats: ManifestStats,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SceneEntry {
    pub status: String,
    pub idx: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ManifestStats {
    pub objects_before: usize,
    pub objects_after: usize,
}

impl Default for Manifest {
    fn default() -> Self {
        Manifest {
            version: 1,
            mode: "AssetBundle".into(),
            bundle_name: "modding_api_asset_bundle".into(),
            scenes: HashMap::new(),
            failed: Vec::new(),
            final_bundle: "final.unity3d".into(),
            stats: ManifestStats::default(),
        }
    }
}

/// 原子写入：先写临时文件再重命名
pub fn write_atomic(path: &Path, data: &[u8]) -> Result<()> {
    let tmp = path.with_extension("tmp");
    {
        let mut f = File::create(&tmp)
            .with_context(|| format!("create tmp for {}", path.display()))?;
        f.write_all(data)
            .with_context(|| format!("write tmp for {}", path.display()))?;
        f.sync_all()?;
    }
    fs::rename(&tmp, path)
        .with_context(|| format!("rename tmp to {}", path.display()))?;
    Ok(())
}

/// 写 manifest（JSON，原子写入）
pub fn write_manifest(cache_dir: &Path, manifest: &Manifest) -> Result<()> {
    let path = cache_dir.join("manifest.json");
    let json = serde_json::to_string_pretty(manifest)?;
    write_atomic(&path, json.as_bytes())
}

/// 读 manifest，不存在则返回 default
pub fn read_manifest(cache_dir: &Path) -> Result<Manifest> {
    let path = cache_dir.join("manifest.json");
    if !path.exists() {
        return Ok(Manifest::default());
    }
    let s = fs::read_to_string(&path)?;
    let manifest = serde_json::from_str(&s)?;
    Ok(manifest)
}

/// 初始化 manifest：根据 scene_objects 建表，已有文件读入状态
pub fn init_manifest(
    cache_dir: &Path,
    scene_objects: &IndexMap<String, Vec<String>>,
    resume: bool,
) -> Result<Manifest> {
    fs::create_dir_all(cache_dir)?;
    if !resume {
        // 清空缓存目录
        for entry in fs::read_dir(cache_dir)? {
            let entry = entry?;
            let path = entry.path();
            if path.is_file() {
                fs::remove_file(&path)?;
            }
        }
    }

    let mut manifest = if resume {
        read_manifest(cache_dir)?
    } else {
        Manifest::default()
    };

    // 重建场景列表（保留已有状态）
    let mut existing = manifest.scenes.clone();
    manifest.scenes.clear();
    for (idx, (scene_name, _paths)) in scene_objects.iter().enumerate() {
        let entry = existing.remove(scene_name).unwrap_or(SceneEntry {
            status: "pending".into(),
            idx,
        });
        manifest.scenes.insert(scene_name.clone(), entry);
    }

    Ok(manifest)
}

/// 标记场景为 done
pub fn mark_scene_done(manifest: &mut Manifest, scene_name: &str) -> Result<()> {
    if let Some(entry) = manifest.scenes.get_mut(scene_name) {
        entry.status = "done".into();
    }
    Ok(())
}

/// 标记场景为 failed
pub fn mark_scene_failed(manifest: &mut Manifest, scene_name: &str) -> Result<()> {
    if let Some(entry) = manifest.scenes.get_mut(scene_name) {
        entry.status = "failed".into();
    }
    if !manifest.failed.contains(&scene_name.to_string()) {
        manifest.failed.push(scene_name.to_string());
    }
    Ok(())
}

/// 中间文件路径
pub fn intermediate_serialized_path(cache_dir: &Path, idx: usize) -> PathBuf {
    cache_dir.join(format!("scene.{idx}.serialized"))
}

pub fn intermediate_meta_path(cache_dir: &Path, idx: usize) -> PathBuf {
    cache_dir.join(format!("scene.{idx}.meta.json"))
}

/// SceneMeta: 单个场景的精简信息（Phase 2 重建 RepackScene 所需）
#[derive(Serialize, Deserialize)]
pub struct SceneMeta {
    pub scene_name: String,
    pub original_name: String,
    pub objects_before: usize,
    pub objects_after: usize,
    pub roots: Vec<(String, i64)>,
    pub replacements: Vec<(i64, Vec<u8>)>,
    pub keep_objects: Vec<i64>,
}

pub fn write_scene_meta(cache_dir: &Path, idx: usize, meta: &SceneMeta) -> Result<()> {
    let path = intermediate_meta_path(cache_dir, idx);
    let json = serde_json::to_string(meta)?;
    write_atomic(&path, json.as_bytes())
}

pub fn read_scene_meta(cache_dir: &Path, idx: usize) -> Result<SceneMeta> {
    let path = intermediate_meta_path(cache_dir, idx);
    let s = fs::read_to_string(&path)?;
    let meta = serde_json::from_str(&s)?;
    Ok(meta)
}

pub fn write_serialized(cache_dir: &Path, idx: usize, data: &[u8]) -> Result<()> {
    let path = intermediate_serialized_path(cache_dir, idx);
    write_atomic(&path, data)
}

pub fn read_serialized(cache_dir: &Path, idx: usize) -> Result<Vec<u8>> {
    let path = intermediate_serialized_path(cache_dir, idx);
    let mut f = File::open(&path)?;
    let mut buf = Vec::new();
    f.read_to_end(&mut buf)?;
    Ok(buf)
}
