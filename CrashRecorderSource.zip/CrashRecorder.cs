using System;
using System.Diagnostics;
using System.IO;
using Modding;
using UnityEngine;

namespace CrashRecorderMod
{
    public class CrashRecorder : Mod
    {
        public CrashRecorder()
        {
            Log("CrashRecorder: constructor");
        }

        public override void Initialize()
        {
            Log("CrashRecorder: Initialize called");
            try
            {
                string dir = Path.Combine(Application.persistentDataPath, "CrashRecorder");
                Directory.CreateDirectory(dir);

                // 每次启动新开一个会话文件；上一次的文件保留，便于区分哪次是崩溃现场
                string session = Path.Combine(dir, "capture_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".txt");

                // 停掉上一次会话遗留的后台 logcat，避免重复堆积
                TryRun("/system/bin/sh", "-c \"pkill -f 'logcat -v time' >/dev/null 2>&1; true\"");

                // 关键：后台常驻 logcat。游戏闪退后这个进程会继续活着，
                // 把崩溃瞬间的底层记录（出错信号、出错地址、调用链）写进文件
                TryRun(
                    "/system/bin/sh",
                    "-c \"echo '== CrashRecorder session start ==' >> '" + session + "'; /system/bin/logcat -v time >> '" + session + "' 2>&1 &\"");

                Log("CrashRecorder: capture file = " + session);
            }
            catch (Exception e)
            {
                Log("CrashRecorder: FAILED: " + e);
            }
        }

        private void TryRun(string file, string args)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = file;
                psi.Arguments = args;
                psi.UseShellExecute = false;
                Process p = Process.Start(psi);
                Log("CrashRecorder: started '" + file + "' pid=" + (p == null ? "null" : p.Id.ToString()));
            }
            catch (Exception e)
            {
                Log("CrashRecorder: '" + file + "' failed: " + e);
            }
        }
    }
}
