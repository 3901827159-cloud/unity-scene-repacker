using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using Modding;
using UnityEngine;

namespace CrashRecorderMod
{
    public class CrashRecorder : Mod
    {
        public CrashRecorder()
        {
            Log("CrashRecorder v2: constructor");
        }

        public override void Initialize()
        {
            Log("CrashRecorder v2: Initialize called");
            try
            {
                string dir = Path.Combine(Application.persistentDataPath, "CrashRecorder");
                Directory.CreateDirectory(dir);
                Log("CrashRecorder v2: dir = " + dir);

                string stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");

                // 1) 启动瞬间先把系统日志缓冲区的最后 6000 行倒出来。
                //    系统日志由系统服务保管，游戏重启后还在；
                //    如果上一次是闪退，崩溃的底层记录就在这里面。这是最稳的一道保险。
                string snap = Path.Combine(dir, "snapshot_" + stamp + ".txt");
                StartLogcat("exec /system/bin/logcat -d -v time -t 6000 >> '" + snap + "' 2>&1", "snapshot", snap);

                // 2) 再启动一个常驻后台进程，持续把系统日志写进文件。
                //    游戏闪退后它会继续活着，把崩溃瞬间那几行补写进文件。
                string session = Path.Combine(dir, "capture_" + stamp + ".txt");
                StartLogcat("pkill -x logcat >/dev/null 2>&1; echo '== stream start ==' >> '" + session + "'; exec /system/bin/logcat -v time >> '" + session + "' 2>&1", "stream", session);

                // 3) 顺手把游戏引擎自己的崩溃报告也倒出来（如果有）
                DumpUnityCrashReports(dir);

                // 4) 3 秒后自查一次：文件到底写出来没有，结果直接进游戏日志
                Thread checker = new Thread(delegate()
                {
                    Thread.Sleep(3000);
                    try
                    {
                        FileInfo fi = new FileInfo(snap);
                        FileInfo fc = new FileInfo(session);
                        Log("CrashRecorder v2: check after 3s -> snapshot exists=" + fi.Exists + " size=" + (fi.Exists ? fi.Length.ToString() : "0")
                            + " ; capture exists=" + fc.Exists + " size=" + (fc.Exists ? fc.Length.ToString() : "0"));
                    }
                    catch (Exception e)
                    {
                        Log("CrashRecorder v2: check failed: " + e.Message);
                    }
                });
                checker.IsBackground = true;
                checker.Start();
            }
            catch (Exception e)
            {
                Log("CrashRecorder v2: FAILED: " + e);
            }
        }

        // 优先用手机系统自带的接口拉起进程（最稳），失败再走备用通道
        private void StartLogcat(string shellCommand, string tag, string outFile)
        {
            try
            {
                StartViaJava(shellCommand);
                Log("CrashRecorder v2: " + tag + " started (system way), file = " + outFile);
                return;
            }
            catch (Exception e1)
            {
                Log("CrashRecorder v2: " + tag + " system way failed: " + e1.Message);
            }

            try
            {
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = "/system/bin/sh";
                psi.Arguments = "-c \"" + shellCommand.Replace("\"", "\\\"") + "\"";
                psi.UseShellExecute = false;
                Process p = Process.Start(psi);
                Log("CrashRecorder v2: " + tag + " started (fallback way), pid=" + (p == null ? "null" : p.Id.ToString()) + ", file = " + outFile);
            }
            catch (Exception e2)
            {
                Log("CrashRecorder v2: " + tag + " fallback failed: " + e2);
            }
        }

        private static void StartViaJava(string shellCommand)
        {
            AndroidJavaObject pb = new AndroidJavaObject("java.lang.ProcessBuilder", "/system/bin/sh", "-c", shellCommand);
            try
            {
                pb.Call<AndroidJavaObject>("redirectErrorStream", true);
                pb.Call<AndroidJavaObject>("start");
            }
            finally
            {
                pb.Dispose();
            }
        }

        private void DumpUnityCrashReports(string dir)
        {
            try
            {
                CrashReport[] reports = CrashReport.reports;
                int n = reports == null ? 0 : reports.Length;
                Log("CrashRecorder v2: engine crash reports = " + n);
                for (int i = 0; i < n; i++)
                {
                    try
                    {
                        string txt = reports[i].text;
                        if (string.IsNullOrEmpty(txt)) txt = "(empty)";
                        File.WriteAllText(Path.Combine(dir, "enginecrash_" + i + ".txt"), txt);
                    }
                    catch { }
                }
            }
            catch (Exception e)
            {
                Log("CrashRecorder v2: engine crash report api failed: " + e.Message);
            }
        }
    }
}
