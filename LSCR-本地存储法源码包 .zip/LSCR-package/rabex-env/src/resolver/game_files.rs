use std::ffi::OsStr;
use std::fs::File;
use std::io::{BufReader, Cursor, ErrorKind};
use std::path::{Path, PathBuf};

use anyhow::{Result, bail, ensure};
use memmap2::Mmap;
use rabex::files::bundlefile::{BundleFileReader, ExtractionConfig};
use walkdir::WalkDir;

use crate::env::Data;
use crate::resolver::{DataOrFile, EnvResolver};

#[derive(Debug)]
pub struct GameFiles {
    pub game_dir: PathBuf,
    pub level_files: LevelFiles,
}

#[derive(Debug)]
pub enum LevelFiles {
    Unpacked,
    Packed(Box<BundleFileReader<Cursor<Mmap>>>),
}

fn find_unity_data_dir(install_dir: &Path) -> Result<Option<PathBuf>> {
    Ok(std::fs::read_dir(install_dir)?
        .filter_map(Result::ok)
        .find_map(|entry| {
            let path = entry.path();
            if is_unity_data_dir(&path) {
                return Some(path);
            }
            // On macOS the player ships as a `.app` bundle with the Unity data
            // dir at `<Game>.app/Contents/Resources/Data`.
            let is_app_bundle = path
                .extension()
                .and_then(OsStr::to_str)
                .is_some_and(|ext| ext.eq_ignore_ascii_case("app"));
            if is_app_bundle {
                let data_dir = path.join("Contents/Resources/Data");
                if data_dir.is_dir() {
                    return Some(data_dir);
                }
            }
            None
        }))
}

fn is_unity_data_dir(dir: &Path) -> bool {
    dir.file_name()
        .and_then(OsStr::to_str)
        .is_some_and(|name| name.ends_with("_Data"))
        && dir.is_dir()
}

impl GameFiles {
    pub fn probe(game_dir: impl AsRef<Path>) -> Result<GameFiles> {
        GameFiles::probe_inner(game_dir.as_ref())
    }

    pub fn probe_dir(game_dir: &Path) -> Result<PathBuf> {
        ensure!(
            game_dir.exists(),
            "Game Directory '{}' does not exist",
            game_dir.display()
        );

        Ok(match is_unity_data_dir(game_dir) {
            true => game_dir.to_owned(),
            false => match find_unity_data_dir(game_dir)? {
                Some(dir) => dir,
                None => {
                    bail!(
                        "Game Directory '{}' is not a unity game. It should have a gamename_Data folder.",
                        game_dir.display()
                    )
                }
            },
        })
    }
    fn probe_inner(game_dir: &Path) -> Result<GameFiles> {
        let game_dir = GameFiles::probe_dir(game_dir)?;

        let bundle_path = game_dir.join("data.unity3d");
        let level_files = if bundle_path.exists() {
            let reader = unsafe { Mmap::map(&File::open(&bundle_path)?)? };
            let bundle =
                BundleFileReader::from_reader(Cursor::new(reader), &ExtractionConfig::default())?;

            LevelFiles::Packed(Box::new(bundle))
        } else {
            LevelFiles::Unpacked
        };

        Ok(GameFiles {
            game_dir: game_dir.to_owned(),
            level_files,
        })
    }

    pub fn read(&self, filename: &str) -> Result<Data, std::io::Error> {
        match &self.level_files {
            LevelFiles::Unpacked => {
                let path = self.game_dir.join(filename);
                let file = File::open(path)?;
                let mmap = unsafe { Mmap::map(&file)? };
                Ok(Data::Mmap(mmap))
            }
            LevelFiles::Packed(bundle) => {
                let data = bundle.read_at(filename)?.ok_or_else(|| {
                    std::io::Error::new(std::io::ErrorKind::NotFound, "File not found in bundle")
                })?;
                Ok(Data::InMemory(data))
            }
        }
    }
}

/// Result of resolving a path against [`GameFiles`]: either an open file on
/// disk or bytes extracted from the packed bundle.
enum Resolved {
    File(File),
    Packed(Vec<u8>),
}

impl GameFiles {
    /// Locate `path` and return either a [`File`] (for unpacked layouts and
    /// `Library/` resources) or the in-memory bytes from the packed bundle.
    /// The caller decides how to consume it (mmap vs. streaming read).
    fn resolve(&self, path: &Path) -> Result<Resolved, std::io::Error> {
        // TODO: consolidate and move away from the trait implementations?
        let mut components = path.components();
        let first = components.next().and_then(|c| c.as_os_str().to_str());
        let is_resource_dir =
            first.is_some_and(|s| matches!(s, "library" | "Library" | "resources" | "Resources"));
        if is_resource_dir {
            let resource_path = self.game_dir.join("Resources").join(&components);
            return File::open(resource_path).map(Resolved::File);
        }

        // PERF: decide on whether to look into packed files based on name?

        let fs_path = self.game_dir.join(path);
        match File::open(&fs_path) {
            Ok(f) => Ok(Resolved::File(f)),
            Err(e) if e.kind() == ErrorKind::NotFound => match &self.level_files {
                LevelFiles::Unpacked => Err(std::io::Error::new(
                    std::io::ErrorKind::NotFound,
                    format!("File '{}' not found", fs_path.display()),
                )),
                LevelFiles::Packed(bundle) => {
                    let path_str = path
                        .to_str()
                        .ok_or_else(|| std::io::Error::other("non-utf8 string"))?;
                    let data = bundle.read_at(path_str)?.ok_or_else(|| {
                        std::io::Error::new(
                            std::io::ErrorKind::NotFound,
                            format!("File '{path_str}' does not exist in bundle"),
                        )
                    })?;
                    Ok(Resolved::Packed(data))
                }
            },
            Err(e) => Err(e),
        }
    }
}

impl EnvResolver for GameFiles {
    type Reader<'a> = DataOrFile;

    fn open_path(&self, path: &Path) -> Result<Self::Reader<'_>, std::io::Error> {
        match self.resolve(path)? {
            Resolved::File(f) => Ok(DataOrFile::File(BufReader::new(f))),
            Resolved::Packed(data) => Ok(DataOrFile::Data(Cursor::new(Data::InMemory(data)))),
        }
    }

    fn read_path(&self, path: &Path) -> Result<Data, std::io::Error> {
        match self.resolve(path)? {
            Resolved::File(f) => {
                let mmap = unsafe { memmap2::Mmap::map(&f)? };
                Ok(Data::Mmap(mmap))
            }
            Resolved::Packed(data) => Ok(Data::InMemory(data)),
        }
    }

    fn all_files(&self) -> Result<Vec<PathBuf>, std::io::Error> {
        match &self.level_files {
            LevelFiles::Unpacked => {
                let mut all = Vec::new();
                for entry in std::fs::read_dir(&self.game_dir)? {
                    let entry = entry?;

                    if entry.file_type()?.is_dir() {
                        continue;
                    }

                    all.push(
                        entry
                            .path()
                            .strip_prefix(&self.game_dir)
                            .unwrap()
                            .to_owned(),
                    );
                }
                Ok(all)
            }
            LevelFiles::Packed(bundle) => {
                // TODO: non-unity3d files as well
                Ok(bundle
                    .files()
                    .iter()
                    .map(|file| file.path.clone().into())
                    .collect())
            }
        }
    }

    fn list_under(&self, prefix: &Path) -> Result<Vec<PathBuf>, std::io::Error> {
        let abs_prefix = self.game_dir.join(prefix);
        let mut out = Vec::new();
        for entry in WalkDir::new(&abs_prefix).into_iter() {
            let entry = entry.map_err(|e| {
                e.into_io_error()
                    .unwrap_or_else(|| std::io::Error::other("walkdir error"))
            })?;
            if entry.file_type().is_dir() {
                continue;
            }
            out.push(
                entry
                    .path()
                    // TODO: validate this is correct
                    .strip_prefix(&self.game_dir)
                    .unwrap()
                    .to_owned(),
            );
        }
        Ok(out)
    }
}
