本地存储法（Local-Storage Chunked Cached Repack，LSCR）源码包
================================================================

本压缩包是"本地存储法"方案涉及的全部源码与文档，供另一位 AI 独立实施参考。

方案文档（先读这个）
--------------------
- Local-Storage-Repack-方案.md  完整方案：背景/根因/三层架构/改造点/数据结构/风险/验证步骤

目录结构与来源
--------------
- unity-scene-repacker/         主仓库（Rust），上游 https://github.com/jakobhellermann/unity-scene-repacker
  - bindings/src/lib.rs         要新增 export_batched 的 C ABI 入口
  - src/lib.rs                  主逻辑（collect_what_to_repack / pack_to_asset_bundle）
  - src/merge_serialized.rs     合并逻辑（add_scene_meta_to_builder / remap_objects）
  - src/pack_to_scene_bundle    中间文件生成模板（trim 逻辑，见 src/lib.rs:380-424）
  注：已去除 .git。fork 仓库为 3901827159-cloud/Unity-scene-repacker，含
      build-android-armv7.yml（armv7 + r26d NDK），云端编译 libunityscenerepacker.so
- rabex/                        解析库，上游 https://github.com/jakobhellermann/rabex
  （原名 rabexsrc，已改名）
- rabex-env/                    Environment 层，上游 https://github.com/jakobhellermann/rabex-env
  - src/resolver/game_files.rs  mmap GameFiles（game_files.rs:183）
- hkmodding-api-csharp/         Modding API C# 侧参考源码（对应手机版内嵌在 Assembly-CSharp 的代码）
  - Preloader.cs                Preload / FullScene 回退 / PreloadBatchSize
  - UnitySceneRepacker.cs       DllImport export + Marshal.Copy + LoadFromMemoryAsync
  - ModLoader.cs / Mod.cs / ModHooks.cs / ModHooksGlobalSettings.cs / 等
  - monobehaviour-typetree-dump.lz4  Modding.monobehaviour-typetree-dump.lz4（导出资源）
  （上游开源地址即 hkmodding-src 对应仓库；手机版与其同源但无独立 Modding.dll）

关键源码位置速查
----------------
- export 本体：unity-scene-repacker/bindings/src/lib.rs:37-76 / export_inner:91-196
- 并行解析爆点：unity-scene-repacker/src/lib.rs:202-208（par_iter 累积所有 RepackScene）
- 合并三份拷贝：unity-scene-repacker/src/lib.rs:466-555
- 小写 prefab 路径：unity-scene-repacker/src/lib.rs:730
- mmap 不占物理内存：rabex-env/src/resolver/game_files.rs:183
- FullScene 回退 / PreloadBatchSize：hkmodding-api-csharp/Preloader.cs:49-61 / ModHooksGlobalSettings.cs:67-73

打包日期：2026-08-29
