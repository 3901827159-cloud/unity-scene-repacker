//! Batched/cached repack support: manifest, intermediate scene files and their metadata.
//!
//! Layout of the cache directory:
//! ```text
//! cache_dir/
//! ├── manifest.json
//! ├── scene.000.serialized      # trimmed serialized file
//! ├── scene.000.meta.json
//! ├── scene.001.serialized
//! ├── ...
//! └── final.unity3d             # written by phase 2
//! ```
use anyhow::{Context, Result, bail};
use indexmap::IndexMap;
use rabex::typetree::TypeTreeNode;
use serde_derive::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use typetree_generator_api::reconstruct_typetree_node;

pub const MANIFEST_FILE: &str = "manifest.json";
pub const MANIFEST_VERSION: u32 = 1;
pub const FINAL_BUNDLE_FILE: &str = "final.unity3d";

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum SceneStatus {
    Pending,
    Done,
    Failed,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SceneEntry {
    pub status: SceneStatus,
    pub idx: usize,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ManifestStats {
    pub objects_before: usize,
    pub objects_after: usize,
    pub size_before: usize,
    pub size_after: usize,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct Manifest {
    pub version: u32,
    pub mode: String,
    pub bundle_name: String,
    /// Ordered map (serde_json preserve_order): merge order = insertion order.
    /// Created from scene names sorted alphabetically for determinism.
    pub scenes: IndexMap<String, SceneEntry>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub stats: Option<ManifestStats>,
}

impl Manifest {
    pub fn new(mode: &str, bundle_name: &str, scene_names: &[String]) -> Self {
        let mut sorted: Vec<&String> = scene_names.iter().collect();
        sorted.sort();
        let scenes = sorted
            .into_iter()
            .enumerate()
            .map(|(idx, name)| {
                (
                    name.clone(),
                    SceneEntry {
                        status: SceneStatus::Pending,
                        idx,
                        error: None,
                    },
                )
            })
            .collect();
        Manifest {
            version: MANIFEST_VERSION,
            mode: mode.to_owned(),
            bundle_name: bundle_name.to_owned(),
            scenes,
            stats: None,
        }
    }

    pub fn path(cache_dir: &Path) -> PathBuf {
        cache_dir.join(MANIFEST_FILE)
    }

    pub fn load(cache_dir: &Path) -> Result<Option<Manifest>> {
        let path = Self::path(cache_dir);
        if !path.exists() {
            return Ok(None);
        }
        let raw = std::fs::read_to_string(&path)
            .with_context(|| format!("reading manifest {}", path.display()))?;
        let manifest: Manifest =
            serde_json::from_str(&raw).with_context(|| "parsing manifest.json")?;
        if manifest.version != MANIFEST_VERSION {
            bail!(
                "unsupported manifest version {} (expected {})",
                manifest.version,
                MANIFEST_VERSION
            );
        }
        Ok(Some(manifest))
    }

    /// Atomic save: write to a temp file then rename, so a killed process can
    /// never leave a half-written manifest behind.
    pub fn save(&self, cache_dir: &Path) -> Result<()> {
        let path = Self::path(cache_dir);
        let tmp = path.with_extension("json.tmp");
        let raw = serde_json::to_string_pretty(self)?;
        std::fs::write(&tmp, raw.as_bytes())
            .with_context(|| format!("writing manifest tmp {}", tmp.display()))?;
        std::fs::rename(&tmp, &path)
            .with_context(|| format!("renaming manifest into place {}", path.display()))?;
        Ok(())
    }

    pub fn done_count(&self) -> usize {
        self.scenes
            .values()
            .filter(|e| e.status == SceneStatus::Done)
            .count()
    }

    pub fn failed_count(&self) -> usize {
        self.scenes
            .values()
            .filter(|e| e.status == SceneStatus::Failed)
            .count()
    }
}

pub fn scene_serialized_path(cache_dir: &Path, idx: usize) -> PathBuf {
    cache_dir.join(format!("scene.{idx:03}.serialized"))
}

pub fn scene_meta_path(cache_dir: &Path, idx: usize) -> PathBuf {
    cache_dir.join(format!("scene.{idx:03}.meta.json"))
}

/// Metadata for one intermediate scene file.
///
/// `roots` stores `(scene_object_path, game_object_path_id)` — the path id is
/// the *original* (pre-merge) id; phase 2 remaps it through `RemapSerializedIndices`.
///
/// `monobehaviour_types` stores flattened typetrees in the same
/// `(name, type, level, flags)` format used by the monobehaviour typetree dump.
#[derive(Debug, Serialize, Deserialize)]
pub struct SceneMeta {
    pub scene_name: String,
    pub original_name: PathBuf,
    pub objects_before: usize,
    pub size_before: usize,
    pub roots: Vec<(String, i64)>,
    pub monobehaviour_types: Vec<(i64, Vec<FlatTypeTreeNode>)>,
}

pub type FlatTypeTreeNode = (String, String, u8, i32);

impl SceneMeta {
    pub fn save(&self, cache_dir: &Path, idx: usize) -> Result<()> {
        let path = scene_meta_path(cache_dir, idx);
        let tmp = path.with_extension("json.tmp");
        let raw = serde_json::to_string(self)?;
        std::fs::write(&tmp, raw.as_bytes())
            .with_context(|| format!("writing meta tmp {}", tmp.display()))?;
        std::fs::rename(&tmp, &path)?;
        Ok(())
    }

    pub fn load(cache_dir: &Path, idx: usize) -> Result<SceneMeta> {
        let path = scene_meta_path(cache_dir, idx);
        let raw = std::fs::read_to_string(&path)
            .with_context(|| format!("reading meta {}", path.display()))?;
        serde_json::from_str(&raw).with_context(|| format!("parsing meta {}", path.display()))
    }

    /// Rebuild owned typetree nodes from the flattened representation.
    pub fn owned_monobehaviour_types(&self) -> FxOwnedTypeTrees {
        self.monobehaviour_types
            .iter()
            .map(|(path_id, flat)| (*path_id, reconstruct_typetree_node(flat)))
            .collect()
    }
}

pub type FxOwnedTypeTrees = rustc_hash::FxHashMap<i64, TypeTreeNode>;

/// Flatten a typetree into `(type, name, level, metaflag)` nodes (depth-first).
///
/// IMPORTANT: `reconstruct_typetree_node` destructures flat nodes as
/// `(type, name, level, flags)` and restores `flags` into `m_MetaFlag`
/// (which drives alignment via `requires_align`). Match that exactly,
/// otherwise traversal misinterprets the serialized data.
pub fn flatten_typetree_node(node: &TypeTreeNode) -> Vec<FlatTypeTreeNode> {
    let mut out = Vec::new();
    fn rec(node: &TypeTreeNode, level: u8, out: &mut Vec<FlatTypeTreeNode>) {
        out.push((
            node.m_Type.clone(),
            node.m_Name.clone(),
            level,
            node.m_MetaFlag.unwrap_or(0),
        ));
        for child in &node.children {
            rec(child, level + 1, out);
        }
    }
    rec(node, 0, &mut out);
    out
}
