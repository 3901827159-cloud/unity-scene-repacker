using System;
using System.IO;
using System.Collections;
using System.Reflection;
using System.Runtime.InteropServices;
using UnityEngine;
using Modding;
using MonoMod.RuntimeDetour;

namespace PreloadCacheMod
{
    public class PreloadCacheMod : Mod
    {
        private static Hook _preloadHook;
        private const string CacheDirName = "ModdingApi.PreloadCache";
        private const string BundleFileName = "final.unity3d";
        private const string ManifestFileName = "manifest.json";

        public override string GetVersion() => "1.0.0";

        public override void Initialize()
        {
            // Hook Preloader.Preload() 方法
            var preloadMethod = typeof(Modding.Preloader).GetMethod("Preload",
                BindingFlags.Public | BindingFlags.Instance);
            if (preloadMethod != null)
            {
                _preloadHook = new Hook(
                    preloadMethod,
                    (Func<Modding.Preloader, IEnumerator>)PreloadReplacement
                );
                Log("PreloadCacheMod: Hook installed.");
            }
            else
            {
                Log("PreloadCacheMod: Failed to find Preload method!");
            }
        }

        private IEnumerator PreloadReplacement(Modding.Preloader instance)
        {
            string persistentPath = Application.persistentDataPath;
            string cachePath = Path.Combine(persistentPath, CacheDirName);
            string bundlePath = Path.Combine(cachePath, BundleFileName);
            string manifestPath = Path.Combine(cachePath, ManifestFileName);

            // ---------- 检查缓存 ----------
            if (File.Exists(bundlePath) && File.Exists(manifestPath))
            {
                Log("PreloadCacheMod: Cache found. Loading from file.");
                byte[] bundleData = File.ReadAllBytes(bundlePath);
                yield return InvokeDoPreloadAssetBundle(instance, bundleData);
                yield break;
            }

            // ---------- 没有缓存，调用 export_batched ----------
            Log("PreloadCacheMod: No cache, building via export_batched.");

            // 获取 gameDir 和 preloadJson
            string gameDir = GetFieldValue<string>(instance, "_gameDir");
            string preloadJson = GetFieldValue<string>(instance, "_preloadJson");

            if (string.IsNullOrEmpty(gameDir) || string.IsNullOrEmpty(preloadJson))
            {
                Log("PreloadCacheMod: Failed to get gameDir/preloadJson, falling back to original.");
                yield return instance.Preload();
                yield break;
            }

            // 创建缓存目录
            Directory.CreateDirectory(cachePath);

            // 调用 export_batched
            try
            {
                IntPtr errorPtr = IntPtr.Zero;
                IntPtr finalPathPtr = IntPtr.Zero;

                IntPtr result = export_batched(
                    "modding_api_asset_bundle",
                    gameDir,
                    preloadJson,
                    cachePath,
                    1, // resume = true
                    out errorPtr,
                    out finalPathPtr,
                    IntPtr.Zero,
                    IntPtr.Zero,
                    0,
                    1 // mode = AssetBundle
                );

                string finalPath = Marshal.PtrToStringAnsi(finalPathPtr);
                if (!string.IsNullOrEmpty(finalPath))
                {
                    bundlePath = finalPath;
                }
                else
                {
                    // 如果没有返回路径，使用默认路径
                    bundlePath = Path.Combine(cachePath, BundleFileName);
                }

                // 检查生成的 bundle 文件是否存在
                if (File.Exists(bundlePath))
                {
                    Log($"PreloadCacheMod: Bundle built at {bundlePath}");
                    byte[] bundleData = File.ReadAllBytes(bundlePath);
                    yield return InvokeDoPreloadAssetBundle(instance, bundleData);
                    yield break;
                }
                else
                {
                    Log("PreloadCacheMod: export_batched succeeded but bundle file not found.");
                }
            }
            catch (Exception e)
            {
                Log($"PreloadCacheMod: export_batched threw exception: {e.Message}");
            }

            // ---------- 如果走到这里，说明一切失败，回退原始 ----------
            Log("PreloadCacheMod: Falling back to original Preload.");
            yield return instance.Preload();
        }

        // ---------- 辅助方法 ----------
        private IEnumerator InvokeDoPreloadAssetBundle(Modding.Preloader instance, byte[] bundleData)
        {
            // 原 DoPreloadAssetBundle 是 private 实例方法，需要反射调用
            var method = typeof(Modding.Preloader).GetMethod(
                "DoPreloadAssetBundle",
                BindingFlags.NonPublic | BindingFlags.Instance
            );

            if (method == null)
            {
                Log("PreloadCacheMod: DoPreloadAssetBundle method not found! Falling back to original Preload.");
                yield return instance.Preload();
                yield break;
            }

            // 调用原方法，参数：byte[] bundleData, bool? noUndo = null
            yield return (IEnumerator)method.Invoke(instance, new object[] { bundleData, null });
        }

        private T GetFieldValue<T>(object obj, string fieldName)
        {
            var field = obj.GetType().GetField(fieldName,
                BindingFlags.NonPublic | BindingFlags.Instance);
            if (field == null)
            {
                Log($"PreloadCacheMod: Field {fieldName} not found.");
                return default(T);
            }
            return (T)field.GetValue(obj);
        }

        private void Log(string msg) => Modding.Logger.Log(msg);

        // ---------- DllImport 声明 ----------
        [DllImport("unityscenerepacker", CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr export_batched(
            string name,
            string game_dir,
            string preload_json,
            string cache_dir,
            int resume_flag,
            out IntPtr error,
            out IntPtr out_final_path,
            IntPtr stats_ret,
            IntPtr mb_typetree_export,
            int mb_typetree_len,
            int mode
        );
    }
}