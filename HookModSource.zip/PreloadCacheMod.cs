using System;
using System.IO;
using System.Collections;
using System.Reflection;
using System.Runtime.InteropServices;
using UnityEngine;
using MonoMod.RuntimeDetour;

namespace PreloadCacheMod
{
    public class PreloadCacheMod : Modding.Mod
    {
        private static Hook _preloadHook;
        private const string CacheDirName = "ModdingApi.PreloadCache";
        private const string BundleFileName = "final.unity3d";
        private const string ManifestFileName = "manifest.json";

        public override string GetVersion() => "1.0.0";

        public override void Initialize()
        {
            // 用反射获取 Preloader 类型（避免编译时访问限制）
            var assembly = Assembly.Load("Assembly-CSharp");
            Type preloaderType = assembly.GetType("Modding.Preloader");
            if (preloaderType == null)
            {
                Log("PreloadCacheMod: Failed to find Modding.Preloader type!");
                return;
            }

            var preloadMethod = preloaderType.GetMethod("Preload",
                BindingFlags.Public | BindingFlags.Instance);
            if (preloadMethod != null)
            {
                _preloadHook = new Hook(
                    preloadMethod,
                    (Func<object, IEnumerator>)PreloadReplacement
                );
                Log("PreloadCacheMod: Hook installed.");
            }
            else
            {
                Log("PreloadCacheMod: Failed to find Preload method!");
            }
        }

        private IEnumerator PreloadReplacement(object instance)
        {
            string persistentPath = Application.persistentDataPath;
            string cachePath = Path.Combine(persistentPath, CacheDirName);
            string bundlePath = Path.Combine(cachePath, BundleFileName);
            string manifestPath = Path.Combine(cachePath, ManifestFileName);

            // ---------- 检查缓存 ----------
            if (File.Exists(bundlePath) && File.Exists(manifestPath))
            {
                Log("PreloadCacheMod: Cache found. Loading from file.");
                byte[] bundleData = File.ReadAllBytes(bundlePath);
                yield return InvokeDoPreloadAssetBundle(instance, bundleData);
                yield break;
            }

            // ---------- 没有缓存，调用 export_batched ----------
            Log("PreloadCacheMod: No cache, building via export_batched.");

            string gameDir = GetFieldValue<string>(instance, "_gameDir");
            string preloadJson = GetFieldValue<string>(instance, "_preloadJson");

            if (string.IsNullOrEmpty(gameDir) || string.IsNullOrEmpty(preloadJson))
            {
                Log("PreloadCacheMod: Failed to get gameDir/preloadJson, falling back to original.");
                yield return InvokeOriginalPreload(instance);
                yield break;
            }

            Directory.CreateDirectory(cachePath);

            try
            {
                IntPtr errorPtr = IntPtr.Zero;
                IntPtr finalPathPtr = IntPtr.Zero;

                IntPtr result = export_batched(
                    "modding_api_asset_bundle",
                    gameDir,
                    preloadJson,
                    cachePath,
                    1, // resume = true
                    out errorPtr,
                    out finalPathPtr,
                    IntPtr.Zero,
                    IntPtr.Zero,
                    0,
                    1 // mode = AssetBundle
                );

                string finalPath = Marshal.PtrToStringAnsi(finalPathPtr);
                if (!string.IsNullOrEmpty(finalPath))
                {
                    bundlePath = finalPath;
                }
                else
                {
                    bundlePath = Path.Combine(cachePath, BundleFileName);
                }

                if (File.Exists(bundlePath))
                {
                    Log($"PreloadCacheMod: Bundle built at {bundlePath}");
                    byte[] bundleData = File.ReadAllBytes(bundlePath);
                    yield return InvokeDoPreloadAssetBundle(instance, bundleData);
                    yield break;
                }
                else
                {
                    Log("PreloadCacheMod: export_batched succeeded but bundle file not found.");
                }
            }
            catch (Exception e)
            {
                Log($"PreloadCacheMod: export_batched threw exception: {e.Message}");
            }

            // ---------- 失败回退 ----------
            Log("PreloadCacheMod: Falling back to original Preload.");
            yield return InvokeOriginalPreload(instance);
        }

        private IEnumerator InvokeDoPreloadAssetBundle(object instance, byte[] bundleData)
        {
            var method = instance.GetType().GetMethod(
                "DoPreloadAssetBundle",
                BindingFlags.NonPublic | BindingFlags.Instance
            );

            if (method == null)
            {
                Log("PreloadCacheMod: DoPreloadAssetBundle not found! Falling back to original.");
                yield return InvokeOriginalPreload(instance);
                yield break;
            }

            yield return (IEnumerator)method.Invoke(instance, new object[] { bundleData, null });
        }

        private IEnumerator InvokeOriginalPreload(object instance)
        {
            var method = instance.GetType().GetMethod("Preload",
                BindingFlags.Public | BindingFlags.Instance);
            if (method != null)
            {
                yield return (IEnumerator)method.Invoke(instance, null);
            }
            else
            {
                Log("PreloadCacheMod: Cannot invoke original Preload, giving up.");
            }
        }

        private T GetFieldValue<T>(object obj, string fieldName)
        {
            var field = obj.GetType().GetField(fieldName,
                BindingFlags.NonPublic | BindingFlags.Instance);
            if (field == null)
            {
                Log($"PreloadCacheMod: Field {fieldName} not found.");
                return default(T);
            }
            return (T)field.GetValue(obj);
        }

        // ---------- DllImport ----------
        [DllImport("unityscenerepacker", CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr export_batched(
            string name,
            string game_dir,
            string preload_json,
            string cache_dir,
            int resume_flag,
            out IntPtr error,
            out IntPtr out_final_path,
            IntPtr stats_ret,
            IntPtr mb_typetree_export,
            int mb_typetree_len,
            int mode
        );
    }
}