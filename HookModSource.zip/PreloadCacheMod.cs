using System;
using Modding;

namespace PreloadCacheMod
{
    public class PreloadCacheMod : Mod
    {
        public override string GetVersion() => "1.0.0";
        public override void Initialize() => Modding.Logger.Log("PreloadCacheMod loaded.");
    }
}