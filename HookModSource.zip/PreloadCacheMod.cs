using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using UnityEngine;
using MonoMod.RuntimeDetour;

namespace PreloadCacheMod
{
    public class PreloadCacheMod : Modding.Mod
    {
        private static Hook _preloadHook;
        private const string CacheDirName = "ModdingApi.PreloadCache";
        private const string BundleFileName = "final.unity3d";
        private const string ManifestFileName = "manifest.json";
        private const string Version = "1.2.2";

        // ===== 预生成 JSON（来自 Kimi v1.2.1，无包装官方格式）=====
        private const string PreloadJsonUnwrapped = @"{""DontDestroyOnLoad"":[""_GameManager/GlobalPool/Gas Explosion Recycle M(Clone)"",""_GameManager/GlobalPool/Gas Explosion Recycle L(Clone)"",""_GameManager/GlobalPool/particle_orange blood(Clone)"",""_GameManager/GlobalPool/particle_orange blood(Clone)/splash"",""_GameManager/GlobalPool/Nail Terrain Hit Effect(Clone)/Particle System"",""_GameManager/GlobalPool/BackdashTriple Effect(Clone)/Grass"",""_GameManager/GlobalPool/BackdashTriple Effect(Clone)/Bone"",""_GameManager/GlobalPool/BackdashTriple Effect(Clone)/Dash Dust"",""_GameManager/GlobalPool/Bounce Spore Small(Clone)"",""_GameManager/GlobalPool/Bounce Spore Large(Clone)"",""_GameManager/GlobalPool/Grimmball(Clone)/Flame_smoke"",""_GameManager/GlobalPool/Grimmball(Clone)/lava_particles_03"",""_GameManager/GlobalPool/Orbit Shield(Clone)/Shield/Idle Pt"",""_GameManager/GlobalPool/Fireball2 Spiral(Clone)/Particle System B"",""_GameManager/GlobalPool/Fireball2 Top(Clone)/particles"",""_GameManager/GlobalPool/Fireball2 Top(Clone)/particles b"",""_GameManager/GlobalPool/Spell Fluke Dung Lv2(Clone)/Knight Dung Cloud/Pt Normal"",""_GameManager/GlobalPool/Spell Fluke Dung Lv2(Clone)/Knight Dung Cloud/Pt Splats"",""_GameManager/GlobalPool/Knight Dung Cloud(Clone)/Pt Deep"",""_GameManager/GlobalPool/Ghost Hit Pt(Clone)"",""_GameManager/GlobalPool/Plat Rocks(Clone)"",""_GameManager/GlobalPool/Dust Land Small R(Clone)"",""_GameManager/GlobalPool/Death Puff Large(Clone)"",""_GameManager/GlobalPool/Death Puff Med(Clone)"",""_GameManager/GlobalPool/Item Get Effect R(Clone)"",""_GameManager/GlobalPool/Shroom Spore Med R(Clone)"",""_GameManager/GlobalPool/Dust Hit Large R(Clone)"",""_GameManager/GlobalPool/Dust Hit Large Down R(Clone)"",""_GameManager/GlobalPool/Dust Hit Med Down R(Clone)"",""_GameManager/GlobalPool/Dust Hit Med R(Clone)"",""_GameManager/GlobalPool/Infected Grass B(Clone)"",""_GameManager/GlobalPool/Infected Grass A(Clone)"",""_GameManager/GlobalPool/Green Grass A(Clone)"",""_GameManager/GlobalPool/White Grass B(Clone)"",""_GameManager/GlobalPool/White Grass A(Clone)"",""_GameManager/GlobalPool/Hit Puff Large(Clone)"",""_GameManager/GlobalPool/Uninfected Death Pt(Clone)"",""_GameManager/GlobalPool/Plat Stream Dust(Clone)/dust_child"",""_GameManager/GlobalPool/Plat Dust(Clone)"",""_GameManager/GlobalPool/break cord particle(Clone)"",""_GameManager/GlobalPool/Geo Large(Clone)/Acid Steam"",""_GameManager/GlobalPool/Hit Shade(Clone)"",""_GameManager/GlobalPool/Hit Puff Med(Clone)"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/abyss particles/wispy smoke"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/fungal_wastes_particles/fung_immediate_BG (1)"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/hive_drip_particles/waterways_drips FG"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/resting_grounds_particles/soul_particles"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/resting_grounds_particles/soul_particles_small"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/dream_particles/bg_dream"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/dream_particles/far bg balls"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/dream_particles/immediate_BG balls"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/dream_particles/fg_dream"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/fog_canyon_particles/Fungus_drips (1)"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/mines_particles/crystals_immediate_BG (4)"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/outskirts_particles/wispy smoke BG (2)"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/white_palace_particles/dream_particle_03 (3)"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/white_palace_particles/Particle System FG"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/white_palace_particles/Particle System BG""],""RESOURCES"":[""Orb Get Black"",""Hollow Shade Death/Shade Particles"",""Corpse Acid Steam"",""Corpse Crawler/Corpse Steam"",""Uninfected Hit Pt"",""Shot Mawlek"",""Spitter Shot R"",""Gas Explosion M"",""Death Puff Boss"",""Dust Impact Med"",""Death Explode Boss"",""Oblobble Shot"",""Gas Explosion M2"",""Shot Mawlek NoDrip"",""Vomit Glob NoiseFix"",""Shot Mantis"",""Mage Orb"",""Shot GladiatorSickle"",""Electro Zap"",""Corpse Mage/Cloak Ash"",""Vomit Glob/Air Steam"",""Dust Land Large"",""Dust Land Med"",""Corpse Big Fly Burster/Burst Effects/Pt Gas"",""Corpse Big Fly Burster/Burst Effects/Pt Plume"",""Bubble Pop"",""Death Puff Dung"",""Shockwave Spurt L"",""Falling Barrel"",""Shockwave Spurt"",""Shockwave Wave/Burst Rocks Stomp"",""Corpse Steam Breath"",""Dust Hit Plume R"",""Dust Land Large R"",""Spawn Roller v2"",""Corpse Blocker/Stun Steam"",""Shot PickAxe"",""Sentry Javelin"",""Corpse Mage Lord 1/Arrive Particles"",""Corpse Hornet 1/Start Pt"",""Roller R"",""Spitter R"",""Buzzer R"",""Corpse_Mossman_Shaker/Green Grass B"",""Corpse_Mossman_Shaker/Green Grass A"",""Shot Orange LG 0.7"",""Corpse Break Puff"",""Spike Ball"",""Spike Ball/Burst Grass"",""Grass Ball"",""Grass Ball/Spore Trail"",""Lil Jellyfish"",""Corpse Jellyfish/Trail"",""Shot Slug Spear"",""Ghost Death/Scatter Pt"",""Gas Projectile"",""Spore Bomb/Spore Fizzle"",""Gas Projectile Quick"",""Corpse Acid Steam S"",""Ghost Warrior Slug"",""Corpse Garden Zombie"",""Shot Spine"",""Shot Traitor Lord"",""Mega Jelly Zap"",""Corpse Mega Jellyfish/Lines/B Line 1 (2)"",""Corpse Crystal Crawler/Crystal Short"",""Crystal Shot/Hit Crystals"",""Baby Centipede"",""Zombie Spider 2"",""Zombie Spider 1"",""Vomit Glob Nosk"",""Galien Hammer"",""Galien Mini Hammer"",""Markoth Shield/Shield"",""Shot Markoth Nail"",""Shot Markoth Nail/Appear Pt"",""Corpse Hornet Outskirts/Enemy Dream"",""IK Projectile DS"",""IK Projectile SH"",""Dung Ball Large"",""Dung Ball Small"",""Dung Ball Large/Chunks"",""Death Puff Boss Dung"",""Shot Kings Guard"",""Flameball Grimmballoon"",""Flameball Grimmballoon Straight"",""Grimm UP Ball"",""Grimm Firebat/Pt Fire"",""Firebat Pillar/particle_flame_blast (1)"",""Flameball Nightmare Straight"",""Nightmare UP Ball"",""Flame Trail"",""Boss Puff Plume"",""Boss Puff Wave"",""Shockwave Spurt L Z"",""Shockwave Spurt Z"",""Shot HK Glob"",""Shot HK Spurt"",""HK Plume"",""Shot HK Shadow"",""HK Plume Prime"",""Paint Shot P Down"",""Paint Shot B_fix"",""Paint Shot R"",""Paint Shot P Up"",""Corpse Sheo/Pt Pink"",""Corpse Sheo/Pt Red"",""Corpse Sheo/Pt Blue"",""Corpse Sheo/Pt Yellow"",""_Props/Health Cocoon"",""Health Scuttler"",""Mace Head Bug""],""Tutorial_01"":[""_Enemies/Crawler 2"",""_Enemies/Buzzer 2"",""_Scenery/Stalactite Hazard"",""_Props/Tut_tablet_top (2)/Glows"",""_Props/Chest/Idle Glow"",""_Props/Stalactite Hazard 5/Dust Stalactite"",""_Props/Stalactite Hazard 5/Dust Fall"",""_Props/Stalactite Hazard 5/Dust Trail"",""_Props/Health Cocoon"",""Health Scuttler"",""_Scenery/Lift_dust"",""_Scenery/Cocoon Plant 1/health plant 01 break/Particle_health_plant_pieces (2)"",""_Scenery/Cocoon Plant 2/health plant 02 break/Particle_health_plant_pieces_many (1)""],""Room_Town_Stag_Station"":[""station_pole/Stag_Pole_Tall_Break (2)/glass_burst pole 1 (1)""],""Room_nailsmith"":[""Nailsmith/Fire/Fire Particles""],""Room_temple"":[""Final Boss Door/Orange Mist""],""Room_ruinhouse"":[""Sly Dazed/Haze""],""Room_Mansion"":[""Xun NPC/Leave Dust/Dust Break 1""],""Room_Fungus_Shaman"":[""Scream Control/Scream Item/Summon 2"",""Mosquito (3)""],""Room_Ouiji"":[""Smoke Activator/Smoke F (1)""],""Room_Colosseum_01"":[""Gold Trial Board/Burst/rag_burst"",""Gold Trial Board/Burst/chain_burst""],""Room_Colosseum_02"":[""Spa Steam (1)""],""Room_Colosseum_Bronze"":[""Colosseum Manager/Waves/Wave 15/Giant Buzzer Col"",""Colosseum Manager/Waves/Wave 1/Colosseum Cage Large"",""Colosseum Manager/Waves/Wave 6/Colosseum Cage Large (1)"",""Colosseum Manager/Waves/Wave 7/Colosseum Cage Small (1)"",""Colosseum Manager/Waves/Wave 29/Colosseum Cage Zote""],""Room_Colosseum_Silver"":[""Colosseum Manager/Waves/Wave 30 Obble/Mega Fat Bee"",""Colosseum Manager/Waves/Wave 26 Obble/Colosseum Cage Small (1)"",""Colosseum_Miner"",""Colosseum_Worm"",""Grub Mimic"",""Giant Fly Col"",""Grub Mimic Bottle""],""Room_Colosseum_Gold"":[""Colosseum Manager/Waves/Garpedes 3/Big Centipede Col (6)"",""Colosseum Manager/Waves/Wave 27/Electric Mage New (1)"",""Colosseum Manager/Waves/Lobster Lancer/Entry Object/Lancer"",""Colosseum Manager/Waves/Lobster Lancer/Entry Object/Lobster"",""Colosseum Manager/Waves/Wave 4/Colosseum Cage Small"",""Colosseum Manager/Waves/Wave 50/Colosseum Cage Large"",""Colosseum Manager/Waves/Wave 10/Colosseum Cage Small (4)"",""Colosseum Manager/Waves/Wave 12/Colosseum Cage Small (3)"",""Colosseum Manager/Waves/Wave 6/Colosseum Cage Large"",""Colosseum Manager/Waves/Wave 45/Colosseum Cage Small 1"",""Colosseum Manager/Waves/Wave 17/Colosseum Cage Small (2)""],""Crossroads_01"":[""Infected Parent/Angry Buzzer"",""_Enemies/Climber 1"",""_Enemies/Zombie Runner"",""_Scenery/Mender Bug"",""Uninfected Parent/BG_swarm_01/particle"",""Uninfected Parent/FG_swarm_01"",""Infected Parent/infected_crossroads_particles/wispy smoke FG left"",""_Scenery/brk_barrel_03 407/Pt Fruit"",""_Scenery/brk_cart_03 406/Pt Bug"",""_Scenery/brk_barrel_03 407/barrel_pieces_burst (4)"",""_Scenery/Crossroads Pole Curvy/Particle_rocks_small""],""Crossroads_02"":[""Uninfected Parent/BG_swarm_01/BG_swarm_02"",""Uninfected Parent/FG_swarm_02""],""Crossroads_04"":[""_Enemies/Zombie Hornhead"",""_Enemies/Giant Fly"",""UnInfected Parent/Zombie Barger"",""Infected Parent/Bursting Zombie"",""_Enemies/Giant Fly/Snore"",""_Scenery/brk_barrel_05/particle_barrel_splash (2)"",""_Enemies/Fly Spawn/Fly""],""Crossroads_07"":[""_Props/Tute Door 1/Break Dust"",""Infected Parent/Bursting Bouncer""],""Crossroads_09"":[""_Enemies/Mawlek Body""],""Crossroads_10"":[""Fk Break Wall/Broken/Battle Gate Break Effect""],""Crossroads_10_boss"":[""Battle Scene/False Knight New"",""Mace Head Bug""],""Crossroads_10_boss_defeated"":[""Prayer Room/Prayer Slug""],""Crossroads_11_alt"":[""Acid Control v2/Acid Box"",""_Scenery/water_components/Fungus_Steam"",""_Scenery/water_components/acid_bursts"",""_Scenery/water_components/acid_bubbles"",""_Enemies/Battle Scene/Blocker""],""Crossroads_12"":[""_Enemies/Worm 1""],""Crossroads_14"":[""Scuttler Spawn 1 (2)/Orange Scuttler (12)""],""Crossroads_15"":[""_Enemies/Zombie Shield 1"",""Infected Parent/Spitting Zombie""],""Crossroads_18"":[""Soul Totem mini_horned/Soul Particles""],""Crossroads_19"":[""_Enemies/Hatcher"",""_Enemies/Zombie Leaper"",""Uninfected Parent/FG_swarm_03"",""Uninfected Parent/glow_bug_swarm 1"",""Uninfected Parent/glow_bug_swarm_FG"",""_Enemies/Spitter""],""Crossroads_21"":[""non_infected_event/Zombie Guard"",""non_infected_event/Zombie Guard/Swipe""],""Crossroads_45"":[""Zombie Myla""],""Crossroads_50"":[""Egg Sac"",""Surface Water Region/Splash Surface""],""Ruins_House_02"":[""Royal Zombie Fat"",""Royal Zombie 1 (1)"",""Royal Zombie Coward"",""Gorgeous Husk""],""Ruins_Bathhouse"":[""ruins_rain/Ruins_Rain""],""Ruins1_01"":[""Ceiling Dropper (1)"",""Ruins Sentry 1""],""Ruins1_03"":[""_Scenery/Ruins Flying Sentry (2)""],""Ruins1_04"":[""Smoke particles""],""Ruins1_05"":[""Ruins Flying Sentry Javelin (3)""],""Ruins1_05c"":[""Ruins Sentry Fat""],""Ruins1_09"":[""mage_particles/Particle System glowies""],""GG_Blue_Room"":[""gg_blue_core""],""Ruins1_27"":[""_Scenery/ruind_fountain/fountain_new/_0083_fountain"",""_Scenery/ruind_fountain/fountain_new/_0082_fountain"",""_Scenery/ruind_fountain/fountain_new/_0092_fountain"",""_Scenery/ruind_fountain/fountain_new/_0092_fountain""],""GG_Workshop"":[""dream_beam_animation"",""GG_Statue_Gorb"",""GG_Statue_Hornet"",""GG_Statue_GreyPrince"",""GG_Statue_Knight/Base/Statue/Knight_v01"",""GG_Statue_Knight/Base/Statue/Knight_v02"",""GG_Statue_Grimm"",""Zote_Appear_bits/GG_Statue_Zote""],""Ruins1_30"":[""Mage Balloon (1)"",""Mage Blob 1 (3)"",""Mage (1)""],""Ruins1_24_boss"":[""Mage Lord"",""Mage Lord Phase2""],""Ruins2_03"":[""_Enemies/Great Shield Zombie""],""Ruins2_03_boss"":[""Battle Control/Black Knight 4"",""Battle Control/Black Knight 4/Bugs In 1"",""Battle Control/Black Knight 4/Bugs In 2"",""Battle Control/Black Knight 4/Entry Steam""],""Ruins2_11_boss"":[""Battle Scene/Jar Collector"",""Battle Scene/Jar Collector/Dust Land""],""Fungus1_01"":[""Moss Walker (3)"",""Plant Trap"",""Mossman_Shaker (1)"",""Pigeon (1)"",""Mossman_Runner""],""Fungus1_04_boss"":[""Hornet Boss 1"",""Hornet Boss 1/Sphere Ball""],""Fungus1_09"":[""Acid Flyer (17)""],""Fungus1_10"":[""Moss Charger 1 (2)""],""Fungus1_12"":[""Plant Turret"",""Plant Turret Right"",""Acid Walker""],""Fungus1_14"":[""Zap Cloud (1)""],""Fungus1_19"":[""_Enemies/Fat Fly""],""Fungus1_20_v02"":[""_Enemies/Giant Buzzer"",""_Scenery/BG_swarm_01/BG_swarm_01 (1)""],""Fungus1_21"":[""Moss Knight"",""Moss Knight/Shot Point""],""Fungus1_23"":[""Grass Hopper (5)""],""Fungus1_26"":[""Lazy Flyer Enemy""],""Fungus1_29"":[""Mega Moss Charger""],""Fungus1_35"":[""Warrior/Ghost Warrior No Eyes""],""Fungus1_Slug"":[""Giant Slug NPC/Pt Bub""],""Fungus2_03"":[""Fungoon Baby (1)"",""Mushroom Turret (2)"",""Fungus Flyer (2)"",""Zombie Fungus B""],""Fungus2_04"":[""Fung Crawler""],""Fungus2_30"":[""Mushroom Brawler""],""Fungus2_07"":[""Mushroom Baby (2)"",""Mushroom Roller""],""Fungus2_10"":[""Zombie Fungus A""],""Fungus2_12"":[""Mantis"",""Mantis Flyer Child""],""Fungus2_15"":[""Deep Spikes (2)""],""Fungus2_29"":[""fungal_core_particles/Fungus_smoke particles"",""fungal_core_particles/Fungus_smoke particles FG""],""Fungus2_32"":[""Warrior/Ghost Warrior Hu"",""Ring Holder""],""Fungus2_33"":[""water component""],""Fungus3_01"":[""Jellyfish Baby (2)"",""_Enemies/Jellyfish 3""],""Fungus3_04"":[""Moss Flyer (1)"",""Mantis Heavy Flyer (1)""],""Fungus3_22"":[""Garden Zombie (1)""],""Fungus3_23"":[""shadow_gate/Slash Effect/Pt Bounce"",""mega_mantis_tall_slash/slash_core/Particle_rocks_long (2)""],""Fungus3_26"":[""Jelly Egg Bomb"",""Zap Cloud""],""Fungus3_23_boss"":[""Battle Scene/Wave 3/Mantis Traitor Lord""],""Fungus3_30"":[""Health Cocoon""],""Fungus3_39"":[""Moss Knight Fat (2)"",""Shiny Spawner/Mantis Heavy Spawn"",""Battle Scene/Mantis Heavy""],""Fungus3_40_boss"":[""Warrior/Ghost Warrior Marmu""],""Fungus3_archive_02"":[""Mega Jellyfish Multizaps/Pattern 2/Mega Jelly Multizap (12)"",""Dreamer Monomon/Particle Control/tank_bubbles_new""],""Cliffs_01"":[""wind system 2""],""Cliffs_05"":[""Butterflies FG 1 (1)"",""Butterflies BG 2""],""RestingGrounds_06"":[""Flamebearer Spawn""],""RestingGrounds_02_boss"":[""Warrior/Ghost Warrior Xero"",""Warrior/Ghost Warrior Xero/Sword 1"",""Warrior/Ghost Warrior Xero/Sword 2"",""Warrior/Ghost Warrior Xero/Sword 3"",""Warrior/Ghost Warrior Xero/Sword 4""],""RestingGrounds_10"":[""Grave Zombie (1)""],""Mines_01"":[""_Scenery/mine_1_quake_floor/Loose Floor 1/Dust F""],""Mines_02"":[""Crystal Crawler (1)"",""Zombie Miner 1 (1)"",""Pt Crystal Dropping (10)""],""Mines_04"":[""Crystal Flyer (2)""],""Mines_05"":[""Crystallised Lazer Bug (1)""],""Mines_06"":[""Laser Turret Frames (4)"",""Laser Turret""],""Mines_10"":[""Flamebearer Spawn""],""Mines_11"":[""Mines Crawler""],""Mines_16"":[""Grub Mimic Top/Dream Dialogue""],""Mines_18_boss"":[""Mega Zombie Beam Miner (1)""],""Mines_23"":[""Zombie Beam Miner (2)""],""Mines_32"":[""Battle Scene/Zombie Beam Miner Rematch"",""Laser Turret Mega""],""Mines_37"":[""stomper_offset (3)"",""stomper_fast""],""Deepnest_03"":[""Zombie Hornhead Sp (4)"",""Zombie Runner Sp"",""Spider Mini (2)""],""Deepnest_26"":[""Centipede Hatcher (2)""],""Deepnest_34"":[""Slash Spider""],""Deepnest_39"":[""Spider Flyer (2)"",""Tiny Spider (7)""],""Deepnest_40"":[""Warrior/Galien Hammer"",""Warrior/Ghost Warrior Galien""],""Deepnest_41"":[""deep_escape_particle spider /spider sil left (1)""],""Deepnest_East_01"":[""Blow Fly (1)"",""Bee Hatchling Ambient (3)"",""Hive flying Bee particles/bee_fg_swarm""],""Deepnest_East_03"":[""ash_grass_03/ash_grass_particles"",""Outskirts_Falling_Gladiator_Particles/Falling FG"",""Outskirts_Falling_Gladiator_Particles/Falling BG""],""Deepnest_East_04"":[""ash_grass_02_sil (7)/ash_grass_particles_windy"",""ash_grass_02_sil (2)/ash_grass_particles_still"",""Super Spitter (4)""],""Deepnest_East_10"":[""Warrior/Ghost Warrior Markoth""],""Deepnest_East_17"":[""Ruins Fossil (3)/debris_particle_fling (2)"",""Giant Geo Egg/Death Effects/Dust Hit Large Down"",""Hopper""],""Deepnest_East_Hornet"":[""Barb Region""],""Deepnest_East_Hornet_boss"":[""Hornet Boss 2""],""Abyss_04"":[""Abyss Crawler (10)""],""Abyss_15"":[""Shade Sibling (14)""],""Abyss_16"":[""Abyss Tendrils""],""Abyss_19"":[""Parasite Balloon (1)"",""Infected Knight/Overhead Slash"",""Pre_Double_Jump/orange smoke""],""Abyss_20"":[""Mawlek Turret (1)"",""Mawlek Turret Ceiling""],""Abyss_21"":[""Shiny Item DJ/Bugs Idle""],""Waterways_01"":[""_Enemies/Flip Hopper (3)"",""_Enemies/Inflater (3)""],""Waterways_04"":[""waterways_water_components (2)"",""Flukeman (1)""],""Waterways_05"":[""Waterways_tank_anim/tank_switch/tank_fill"",""Waterways_tank_anim/tank_return/tank_full""],""Waterways_05_boss"":[""Dung Defender""],""Waterways_08"":[""fluke_baby_02 (32)"",""fluke_baby_01 (20)"",""fluke_baby_03 (7)"",""Fluke Fly (4)""],""Waterways_12_boss"":[""Fluke Mother""],""White_Palace_01"":[""White Palace Fly (2)"",""White_ Spikes (5)""],""White_Palace_03_hub"":[""White_Servant_03 (3)/Enemy""],""White_Palace_04"":[""_Scenery/wp_saw_04_anims/saw1/wp_saw (1)""],""White_Palace_11"":[""Royal Gaurd""],""Hive_01"":[""Bee Stinger""],""Hive_03"":[""Flamebearer Spawn"",""Big Bee (2)""],""Hive_04"":[""hive_moving diamonds (1)"",""Zombie Hive (6)""],""Hive_05"":[""Battle Scene/Hive Knight"",""Battle Scene/Hive Knight/Mouth Swarm/particle_honey_spit"",""Battle Scene/Droppers/Bee Dropper""],""Grimm_Main_Tent"":[""Spotlight Appear/Appear_moving spotlights/Grimm_appear_smoke/wide_smoke_front"",""Spotlight Appear/Appear_moving spotlights/Grimm_appear_smoke/grimm_big_appear_burst""],""Grimm_Main_Tent_boss"":[""Grimm Boss""],""Grimm_Nightmare"":[""Grimm Control/Nightmare Grimm Boss""],""Dream_01_False_Knight"":[""False Knight Dream""],""Dream_02_Mage_Lord"":[""Dream Mage Lord""],""Dream_03_Infected_Knight"":[""Lost Kin""],""Dream_Mighty_Zote"":[""Zoteling (2)"",""Zote Balloon (3)"",""Grey Prince""],""Dream_Final_Boss"":[""Boss Control/Radiance"",""Boss Control/Radiance Roar/Roar Feathers"",""Boss Control/Radiance/Pt Feather Burst"",""Boss Control/Abyss Pit/Pt Mist"",""Boss Control/Abyss Pit/Pt Surface""],""Room_Final_Boss_Core"":[""Boss Control/Hollow Knight Boss""],""GG_Atrium"":[""GG_Challenge_Door (1)/Door/Lock Break/lock burst"",""gg_atrium_hidden_path/gg_roof open_effect/wispy smoke object (2)""],""GG_Hollow_Knight"":[""Battle Scene/HK Prime""],""GG_Lurker"":[""Lurker Control/Pale Lurker"",""Lurker Control/Pale Lurker/Slash Ball""],""GG_Nailmasters"":[""Brothers/Oro"",""Brothers/Mato""],""GG_Painter"":[""Battle Scene/Sheo Boss""],""GG_Pipeway"":[""Fat Fluke""],""GG_Radiance"":[""Boss Control/Absolute Radiance""],""GG_Sly"":[""Battle Scene/Sly Boss""],""GG_Mighty_Zote"":[""Zote Turret"",""Battle Control/First Zote/Zote Boss"",""Battle Control/Zote Balloon Ordeal"",""Battle Control/Zote Salubra"",""Battle Control/Zote Thwomp"",""Battle Control/Zote Fluke"",""Battle Control/Fat Zotes/Zote Crew Fat (1)"",""Battle Control/Zote Thwomp/Pt Break"",""Battle Control/Zotelings/Ordeal Zoteling"",""Battle Control/Tall Zotes/Zote Crew Tall"",""Battle Control/Dormant Warriors/Zote Crew Normal (1)"",""Battle Control/Music""],""GG_Brooding_Mawlek_V"":[""Battle Scene/Tiso Boss"",""Battle Scene/Tiso Boss/Corpse""],""GG_Nosk_Hornet"":[""Battle Scene/Hornet Nosk""],""Ruins1_23"":[""Mage Knight""],""Deepnest_East_06"":[""Giant Hopper (2)""],""Abyss_17"":[""Lesser Mawlek""],""Dream_04_White_Defender"":[""White Defender""],""GG_Broken_Vessel"":[""Infected Knight""],""GG_Nosk"":[""Mimic Spider""],""GG_Soul_Tyrant"":[""Dream Mage Lord Phase2""],""GG_Uumuu"":[""Mega Jellyfish GG""]}";

        // 带 scene_objects 包装的版本（兜底）
        private const string PreloadJsonWrapped = @"{""scene_objects"":{""DontDestroyOnLoad"":[""_GameManager/GlobalPool/Gas Explosion Recycle M(Clone)"",""_GameManager/GlobalPool/Gas Explosion Recycle L(Clone)"",""_GameManager/GlobalPool/particle_orange blood(Clone)"",""_GameManager/GlobalPool/particle_orange blood(Clone)/splash"",""_GameManager/GlobalPool/Nail Terrain Hit Effect(Clone)/Particle System"",""_GameManager/GlobalPool/BackdashTriple Effect(Clone)/Grass"",""_GameManager/GlobalPool/BackdashTriple Effect(Clone)/Bone"",""_GameManager/GlobalPool/BackdashTriple Effect(Clone)/Dash Dust"",""_GameManager/GlobalPool/Bounce Spore Small(Clone)"",""_GameManager/GlobalPool/Bounce Spore Large(Clone)"",""_GameManager/GlobalPool/Grimmball(Clone)/Flame_smoke"",""_GameManager/GlobalPool/Grimmball(Clone)/lava_particles_03"",""_GameManager/GlobalPool/Orbit Shield(Clone)/Shield/Idle Pt"",""_GameManager/GlobalPool/Fireball2 Spiral(Clone)/Particle System B"",""_GameManager/GlobalPool/Fireball2 Top(Clone)/particles"",""_GameManager/GlobalPool/Fireball2 Top(Clone)/particles b"",""_GameManager/GlobalPool/Spell Fluke Dung Lv2(Clone)/Knight Dung Cloud/Pt Normal"",""_GameManager/GlobalPool/Spell Fluke Dung Lv2(Clone)/Knight Dung Cloud/Pt Splats"",""_GameManager/GlobalPool/Knight Dung Cloud(Clone)/Pt Deep"",""_GameManager/GlobalPool/Ghost Hit Pt(Clone)"",""_GameManager/GlobalPool/Plat Rocks(Clone)"",""_GameManager/GlobalPool/Dust Land Small R(Clone)"",""_GameManager/GlobalPool/Death Puff Large(Clone)"",""_GameManager/GlobalPool/Death Puff Med(Clone)"",""_GameManager/GlobalPool/Item Get Effect R(Clone)"",""_GameManager/GlobalPool/Shroom Spore Med R(Clone)"",""_GameManager/GlobalPool/Dust Hit Large R(Clone)"",""_GameManager/GlobalPool/Dust Hit Large Down R(Clone)"",""_GameManager/GlobalPool/Dust Hit Med Down R(Clone)"",""_GameManager/GlobalPool/Dust Hit Med R(Clone)"",""_GameManager/GlobalPool/Infected Grass B(Clone)"",""_GameManager/GlobalPool/Infected Grass A(Clone)"",""_GameManager/GlobalPool/Green Grass A(Clone)"",""_GameManager/GlobalPool/White Grass B(Clone)"",""_GameManager/GlobalPool/White Grass A(Clone)"",""_GameManager/GlobalPool/Hit Puff Large(Clone)"",""_GameManager/GlobalPool/Uninfected Death Pt(Clone)"",""_GameManager/GlobalPool/Plat Stream Dust(Clone)/dust_child"",""_GameManager/GlobalPool/Plat Dust(Clone)"",""_GameManager/GlobalPool/break cord particle(Clone)"",""_GameManager/GlobalPool/Geo Large(Clone)/Acid Steam"",""_GameManager/GlobalPool/Hit Shade(Clone)"",""_GameManager/GlobalPool/Hit Puff Med(Clone)"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/abyss particles/wispy smoke"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/fungal_wastes_particles/fung_immediate_BG (1)"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/hive_drip_particles/waterways_drips FG"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/resting_grounds_particles/soul_particles"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/resting_grounds_particles/soul_particles_small"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/dream_particles/bg_dream"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/dream_particles/far bg balls"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/dream_particles/immediate_BG balls"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/dream_particles/fg_dream"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/fog_canyon_particles/Fungus_drips (1)"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/mines_particles/crystals_immediate_BG (4)"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/outskirts_particles/wispy smoke BG (2)"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/white_palace_particles/dream_particle_03 (3)"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/white_palace_particles/Particle System FG"",""_GameCameras/CameraParent/tk2dCamera/SceneParticlesController/white_palace_particles/Particle System BG""],""RESOURCES"":[""Orb Get Black"",""Hollow Shade Death/Shade Particles"",""Corpse Acid Steam"",""Corpse Crawler/Corpse Steam"",""Uninfected Hit Pt"",""Shot Mawlek"",""Spitter Shot R"",""Gas Explosion M"",""Death Puff Boss"",""Dust Impact Med"",""Death Explode Boss"",""Oblobble Shot"",""Gas Explosion M2"",""Shot Mawlek NoDrip"",""Vomit Glob NoiseFix"",""Shot Mantis"",""Mage Orb"",""Shot GladiatorSickle"",""Electro Zap"",""Corpse Mage/Cloak Ash"",""Vomit Glob/Air Steam"",""Dust Land Large"",""Dust Land Med"",""Corpse Big Fly Burster/Burst Effects/Pt Gas"",""Corpse Big Fly Burster/Burst Effects/Pt Plume"",""Bubble Pop"",""Death Puff Dung"",""Shockwave Spurt L"",""Falling Barrel"",""Shockwave Spurt"",""Shockwave Wave/Burst Rocks Stomp"",""Corpse Steam Breath"",""Dust Hit Plume R"",""Dust Land Large R"",""Spawn Roller v2"",""Corpse Blocker/Stun Steam"",""Shot PickAxe"",""Sentry Javelin"",""Corpse Mage Lord 1/Arrive Particles"",""Corpse Hornet 1/Start Pt"",""Roller R"",""Spitter R"",""Buzzer R"",""Corpse_Mossman_Shaker/Green Grass B"",""Corpse_Mossman_Shaker/Green Grass A"",""Shot Orange LG 0.7"",""Corpse Break Puff"",""Spike Ball"",""Spike Ball/Burst Grass"",""Grass Ball"",""Grass Ball/Spore Trail"",""Lil Jellyfish"",""Corpse Jellyfish/Trail"",""Shot Slug Spear"",""Ghost Death/Scatter Pt"",""Gas Projectile"",""Spore Bomb/Spore Fizzle"",""Gas Projectile Quick"",""Corpse Acid Steam S"",""Ghost Warrior Slug"",""Corpse Garden Zombie"",""Shot Spine"",""Shot Traitor Lord"",""Mega Jelly Zap"",""Corpse Mega Jellyfish/Lines/B Line 1 (2)"",""Corpse Crystal Crawler/Crystal Short"",""Crystal Shot/Hit Crystals"",""Baby Centipede"",""Zombie Spider 2"",""Zombie Spider 1"",""Vomit Glob Nosk"",""Galien Hammer"",""Galien Mini Hammer"",""Markoth Shield/Shield"",""Shot Markoth Nail"",""Shot Markoth Nail/Appear Pt"",""Corpse Hornet Outskirts/Enemy Dream"",""IK Projectile DS"",""IK Projectile SH"",""Dung Ball Large"",""Dung Ball Small"",""Dung Ball Large/Chunks"",""Death Puff Boss Dung"",""Shot Kings Guard"",""Flameball Grimmballoon"",""Flameball Grimmballoon Straight"",""Grimm UP Ball"",""Grimm Firebat/Pt Fire"",""Firebat Pillar/particle_flame_blast (1)"",""Flameball Nightmare Straight"",""Nightmare UP Ball"",""Flame Trail"",""Boss Puff Plume"",""Boss Puff Wave"",""Shockwave Spurt L Z"",""Shockwave Spurt Z"",""Shot HK Glob"",""Shot HK Spurt"",""HK Plume"",""Shot HK Shadow"",""HK Plume Prime"",""Paint Shot P Down"",""Paint Shot B_fix"",""Paint Shot R"",""Paint Shot P Up"",""Corpse Sheo/Pt Pink"",""Corpse Sheo/Pt Red"",""Corpse Sheo/Pt Blue"",""Corpse Sheo/Pt Yellow"",""_Props/Health Cocoon"",""Health Scuttler"",""Mace Head Bug""],""Tutorial_01"":[""_Enemies/Crawler 2"",""_Enemies/Buzzer 2"",""_Scenery/Stalactite Hazard"",""_Props/Tut_tablet_top (2)/Glows"",""_Props/Chest/Idle Glow"",""_Props/Stalactite Hazard 5/Dust Stalactite"",""_Props/Stalactite Hazard 5/Dust Fall"",""_Props/Stalactite Hazard 5/Dust Trail"",""_Props/Health Cocoon"",""Health Scuttler"",""_Scenery/Lift_dust"",""_Scenery/Cocoon Plant 1/health plant 01 break/Particle_health_plant_pieces (2)"",""_Scenery/Cocoon Plant 2/health plant 02 break/Particle_health_plant_pieces_many (1)""],""Room_Town_Stag_Station"":[""station_pole/Stag_Pole_Tall_Break (2)/glass_burst pole 1 (1)""],""Room_nailsmith"":[""Nailsmith/Fire/Fire Particles""],""Room_temple"":[""Final Boss Door/Orange Mist""],""Room_ruinhouse"":[""Sly Dazed/Haze""],""Room_Mansion"":[""Xun NPC/Leave Dust/Dust Break 1""],""Room_Fungus_Shaman"":[""Scream Control/Scream Item/Summon 2"",""Mosquito (3)""],""Room_Ouiji"":[""Smoke Activator/Smoke F (1)""],""Room_Colosseum_01"":[""Gold Trial Board/Burst/rag_burst"",""Gold Trial Board/Burst/chain_burst""],""Room_Colosseum_02"":[""Spa Steam (1)""],""Room_Colosseum_Bronze"":[""Colosseum Manager/Waves/Wave 15/Giant Buzzer Col"",""Colosseum Manager/Waves/Wave 1/Colosseum Cage Large"",""Colosseum Manager/Waves/Wave 6/Colosseum Cage Large (1)"",""Colosseum Manager/Waves/Wave 7/Colosseum Cage Small (1)"",""Colosseum Manager/Waves/Wave 29/Colosseum Cage Zote""],""Room_Colosseum_Silver"":[""Colosseum Manager/Waves/Wave 30 Obble/Mega Fat Bee"",""Colosseum Manager/Waves/Wave 26 Obble/Colosseum Cage Small (1)"",""Colosseum_Miner"",""Colosseum_Worm"",""Grub Mimic"",""Giant Fly Col"",""Grub Mimic Bottle""],""Room_Colosseum_Gold"":[""Colosseum Manager/Waves/Garpedes 3/Big Centipede Col (6)"",""Colosseum Manager/Waves/Wave 27/Electric Mage New (1)"",""Colosseum Manager/Waves/Lobster Lancer/Entry Object/Lancer"",""Colosseum Manager/Waves/Lobster Lancer/Entry Object/Lobster"",""Colosseum Manager/Waves/Wave 4/Colosseum Cage Small"",""Colosseum Manager/Waves/Wave 50/Colosseum Cage Large"",""Colosseum Manager/Waves/Wave 10/Colosseum Cage Small (4)"",""Colosseum Manager/Waves/Wave 12/Colosseum Cage Small (3)"",""Colosseum Manager/Waves/Wave 6/Colosseum Cage Large"",""Colosseum Manager/Waves/Wave 45/Colosseum Cage Small 1"",""Colosseum Manager/Waves/Wave 17/Colosseum Cage Small (2)""],""Crossroads_01"":[""Infected Parent/Angry Buzzer"",""_Enemies/Climber 1"",""_Enemies/Zombie Runner"",""_Scenery/Mender Bug"",""Uninfected Parent/BG_swarm_01/particle"",""Uninfected Parent/FG_swarm_01"",""Infected Parent/infected_crossroads_particles/wispy smoke FG left"",""_Scenery/brk_barrel_03 407/Pt Fruit"",""_Scenery/brk_cart_03 406/Pt Bug"",""_Scenery/brk_barrel_03 407/barrel_pieces_burst (4)"",""_Scenery/Crossroads Pole Curvy/Particle_rocks_small""],""Crossroads_02"":[""Uninfected Parent/BG_swarm_01/BG_swarm_02"",""Uninfected Parent/FG_swarm_02""],""Crossroads_04"":[""_Enemies/Zombie Hornhead"",""_Enemies/Giant Fly"",""UnInfected Parent/Zombie Barger"",""Infected Parent/Bursting Zombie"",""_Enemies/Giant Fly/Snore"",""_Scenery/brk_barrel_05/particle_barrel_splash (2)"",""_Enemies/Fly Spawn/Fly""],""Crossroads_07"":[""_Props/Tute Door 1/Break Dust"",""Infected Parent/Bursting Bouncer""],""Crossroads_09"":[""_Enemies/Mawlek Body""],""Crossroads_10"":[""Fk Break Wall/Broken/Battle Gate Break Effect""],""Crossroads_10_boss"":[""Battle Scene/False Knight New"",""Mace Head Bug""],""Crossroads_10_boss_defeated"":[""Prayer Room/Prayer Slug""],""Crossroads_11_alt"":[""Acid Control v2/Acid Box"",""_Scenery/water_components/Fungus_Steam"",""_Scenery/water_components/acid_bursts"",""_Scenery/water_components/acid_bubbles"",""_Enemies/Battle Scene/Blocker""],""Crossroads_12"":[""_Enemies/Worm 1""],""Crossroads_14"":[""Scuttler Spawn 1 (2)/Orange Scuttler (12)""],""Crossroads_15"":[""_Enemies/Zombie Shield 1"",""Infected Parent/Spitting Zombie""],""Crossroads_18"":[""Soul Totem mini_horned/Soul Particles""],""Crossroads_19"":[""_Enemies/Hatcher"",""_Enemies/Zombie Leaper"",""Uninfected Parent/FG_swarm_03"",""Uninfected Parent/glow_bug_swarm 1"",""Uninfected Parent/glow_bug_swarm_FG"",""_Enemies/Spitter""],""Crossroads_21"":[""non_infected_event/Zombie Guard"",""non_infected_event/Zombie Guard/Swipe""],""Crossroads_45"":[""Zombie Myla""],""Crossroads_50"":[""Egg Sac"",""Surface Water Region/Splash Surface""],""Ruins_House_02"":[""Royal Zombie Fat"",""Royal Zombie 1 (1)"",""Royal Zombie Coward"",""Gorgeous Husk""],""Ruins_Bathhouse"":[""ruins_rain/Ruins_Rain""],""Ruins1_01"":[""Ceiling Dropper (1)"",""Ruins Sentry 1""],""Ruins1_03"":[""_Scenery/Ruins Flying Sentry (2)""],""Ruins1_04"":[""Smoke particles""],""Ruins1_05"":[""Ruins Flying Sentry Javelin (3)""],""Ruins1_05c"":[""Ruins Sentry Fat""],""Ruins1_09"":[""mage_particles/Particle System glowies""],""GG_Blue_Room"":[""gg_blue_core""],""Ruins1_27"":[""_Scenery/ruind_fountain/fountain_new/_0083_fountain"",""_Scenery/ruind_fountain/fountain_new/_0082_fountain"",""_Scenery/ruind_fountain/fountain_new/_0092_fountain"",""_Scenery/ruind_fountain/fountain_new/_0092_fountain""],""GG_Workshop"":[""dream_beam_animation"",""GG_Statue_Gorb"",""GG_Statue_Hornet"",""GG_Statue_GreyPrince"",""GG_Statue_Knight/Base/Statue/Knight_v01"",""GG_Statue_Knight/Base/Statue/Knight_v02"",""GG_Statue_Grimm"",""Zote_Appear_bits/GG_Statue_Zote""],""Ruins1_30"":[""Mage Balloon (1)"",""Mage Blob 1 (3)"",""Mage (1)""],""Ruins1_24_boss"":[""Mage Lord"",""Mage Lord Phase2""],""Ruins2_03"":[""_Enemies/Great Shield Zombie""],""Ruins2_03_boss"":[""Battle Control/Black Knight 4"",""Battle Control/Black Knight 4/Bugs In 1"",""Battle Control/Black Knight 4/Bugs In 2"",""Battle Control/Black Knight 4/Entry Steam""],""Ruins2_11_boss"":[""Battle Scene/Jar Collector"",""Battle Scene/Jar Collector/Dust Land""],""Fungus1_01"":[""Moss Walker (3)"",""Plant Trap"",""Mossman_Shaker (1)"",""Pigeon (1)"",""Mossman_Runner""],""Fungus1_04_boss"":[""Hornet Boss 1"",""Hornet Boss 1/Sphere Ball""],""Fungus1_09"":[""Acid Flyer (17)""],""Fungus1_10"":[""Moss Charger 1 (2)""],""Fungus1_12"":[""Plant Turret"",""Plant Turret Right"",""Acid Walker""],""Fungus1_14"":[""Zap Cloud (1)""],""Fungus1_19"":[""_Enemies/Fat Fly""],""Fungus1_20_v02"":[""_Enemies/Giant Buzzer"",""_Scenery/BG_swarm_01/BG_swarm_01 (1)""],""Fungus1_21"":[""Moss Knight"",""Moss Knight/Shot Point""],""Fungus1_23"":[""Grass Hopper (5)""],""Fungus1_26"":[""Lazy Flyer Enemy""],""Fungus1_29"":[""Mega Moss Charger""],""Fungus1_35"":[""Warrior/Ghost Warrior No Eyes""],""Fungus1_Slug"":[""Giant Slug NPC/Pt Bub""],""Fungus2_03"":[""Fungoon Baby (1)"",""Mushroom Turret (2)"",""Fungus Flyer (2)"",""Zombie Fungus B""],""Fungus2_04"":[""Fung Crawler""],""Fungus2_30"":[""Mushroom Brawler""],""Fungus2_07"":[""Mushroom Baby (2)"",""Mushroom Roller""],""Fungus2_10"":[""Zombie Fungus A""],""Fungus2_12"":[""Mantis"",""Mantis Flyer Child""],""Fungus2_15"":[""Deep Spikes (2)""],""Fungus2_29"":[""fungal_core_particles/Fungus_smoke particles"",""fungal_core_particles/Fungus_smoke particles FG""],""Fungus2_32"":[""Warrior/Ghost Warrior Hu"",""Ring Holder""],""Fungus2_33"":[""water component""],""Fungus3_01"":[""Jellyfish Baby (2)"",""_Enemies/Jellyfish 3""],""Fungus3_04"":[""Moss Flyer (1)"",""Mantis Heavy Flyer (1)""],""Fungus3_22"":[""Garden Zombie (1)""],""Fungus3_23"":[""shadow_gate/Slash Effect/Pt Bounce"",""mega_mantis_tall_slash/slash_core/Particle_rocks_long (2)""],""Fungus3_26"":[""Jelly Egg Bomb"",""Zap Cloud""],""Fungus3_23_boss"":[""Battle Scene/Wave 3/Mantis Traitor Lord""],""Fungus3_30"":[""Health Cocoon""],""Fungus3_39"":[""Moss Knight Fat (2)"",""Shiny Spawner/Mantis Heavy Spawn"",""Battle Scene/Mantis Heavy""],""Fungus3_40_boss"":[""Warrior/Ghost Warrior Marmu""],""Fungus3_archive_02"":[""Mega Jellyfish Multizaps/Pattern 2/Mega Jelly Multizap (12)"",""Dreamer Monomon/Particle Control/tank_bubbles_new""],""Cliffs_01"":[""wind system 2""],""Cliffs_05"":[""Butterflies FG 1 (1)"",""Butterflies BG 2""],""RestingGrounds_06"":[""Flamebearer Spawn""],""RestingGrounds_02_boss"":[""Warrior/Ghost Warrior Xero"",""Warrior/Ghost Warrior Xero/Sword 1"",""Warrior/Ghost Warrior Xero/Sword 2"",""Warrior/Ghost Warrior Xero/Sword 3"",""Warrior/Ghost Warrior Xero/Sword 4""],""RestingGrounds_10"":[""Grave Zombie (1)""],""Mines_01"":[""_Scenery/mine_1_quake_floor/Loose Floor 1/Dust F""],""Mines_02"":[""Crystal Crawler (1)"",""Zombie Miner 1 (1)"",""Pt Crystal Dropping (10)""],""Mines_04"":[""Crystal Flyer (2)""],""Mines_05"":[""Crystallised Lazer Bug (1)""],""Mines_06"":[""Laser Turret Frames (4)"",""Laser Turret""],""Mines_10"":[""Flamebearer Spawn""],""Mines_11"":[""Mines Crawler""],""Mines_16"":[""Grub Mimic Top/Dream Dialogue""],""Mines_18_boss"":[""Mega Zombie Beam Miner (1)""],""Mines_23"":[""Zombie Beam Miner (2)""],""Mines_32"":[""Battle Scene/Zombie Beam Miner Rematch"",""Laser Turret Mega""],""Mines_37"":[""stomper_offset (3)"",""stomper_fast""],""Deepnest_03"":[""Zombie Hornhead Sp (4)"",""Zombie Runner Sp"",""Spider Mini (2)""],""Deepnest_26"":[""Centipede Hatcher (2)""],""Deepnest_34"":[""Slash Spider""],""Deepnest_39"":[""Spider Flyer (2)"",""Tiny Spider (7)""],""Deepnest_40"":[""Warrior/Galien Hammer"",""Warrior/Ghost Warrior Galien""],""Deepnest_41"":[""deep_escape_particle spider /spider sil left (1)""],""Deepnest_East_01"":[""Blow Fly (1)"",""Bee Hatchling Ambient (3)"",""Hive flying Bee particles/bee_fg_swarm""],""Deepnest_East_03"":[""ash_grass_03/ash_grass_particles"",""Outskirts_Falling_Gladiator_Particles/Falling FG"",""Outskirts_Falling_Gladiator_Particles/Falling BG""],""Deepnest_East_04"":[""ash_grass_02_sil (7)/ash_grass_particles_windy"",""ash_grass_02_sil (2)/ash_grass_particles_still"",""Super Spitter (4)""],""Deepnest_East_10"":[""Warrior/Ghost Warrior Markoth""],""Deepnest_East_17"":[""Ruins Fossil (3)/debris_particle_fling (2)"",""Giant Geo Egg/Death Effects/Dust Hit Large Down"",""Hopper""],""Deepnest_East_Hornet"":[""Barb Region""],""Deepnest_East_Hornet_boss"":[""Hornet Boss 2""],""Abyss_04"":[""Abyss Crawler (10)""],""Abyss_15"":[""Shade Sibling (14)""],""Abyss_16"":[""Abyss Tendrils""],""Abyss_19"":[""Parasite Balloon (1)"",""Infected Knight/Overhead Slash"",""Pre_Double_Jump/orange smoke""],""Abyss_20"":[""Mawlek Turret (1)"",""Mawlek Turret Ceiling""],""Abyss_21"":[""Shiny Item DJ/Bugs Idle""],""Waterways_01"":[""_Enemies/Flip Hopper (3)"",""_Enemies/Inflater (3)""],""Waterways_04"":[""waterways_water_components (2)"",""Flukeman (1)""],""Waterways_05"":[""Waterways_tank_anim/tank_switch/tank_fill"",""Waterways_tank_anim/tank_return/tank_full""],""Waterways_05_boss"":[""Dung Defender""],""Waterways_08"":[""fluke_baby_02 (32)"",""fluke_baby_01 (20)"",""fluke_baby_03 (7)"",""Fluke Fly (4)""],""Waterways_12_boss"":[""Fluke Mother""],""White_Palace_01"":[""White Palace Fly (2)"",""White_ Spikes (5)""],""White_Palace_03_hub"":[""White_Servant_03 (3)/Enemy""],""White_Palace_04"":[""_Scenery/wp_saw_04_anims/saw1/wp_saw (1)""],""White_Palace_11"":[""Royal Gaurd""],""Hive_01"":[""Bee Stinger""],""Hive_03"":[""Flamebearer Spawn"",""Big Bee (2)""],""Hive_04"":[""hive_moving diamonds (1)"",""Zombie Hive (6)""],""Hive_05"":[""Battle Scene/Hive Knight"",""Battle Scene/Hive Knight/Mouth Swarm/particle_honey_spit"",""Battle Scene/Droppers/Bee Dropper""],""Grimm_Main_Tent"":[""Spotlight Appear/Appear_moving spotlights/Grimm_appear_smoke/wide_smoke_front"",""Spotlight Appear/Appear_moving spotlights/Grimm_appear_smoke/grimm_big_appear_burst""],""Grimm_Main_Tent_boss"":[""Grimm Boss""],""Grimm_Nightmare"":[""Grimm Control/Nightmare Grimm Boss""],""Dream_01_False_Knight"":[""False Knight Dream""],""Dream_02_Mage_Lord"":[""Dream Mage Lord""],""Dream_03_Infected_Knight"":[""Lost Kin""],""Dream_Mighty_Zote"":[""Zoteling (2)"",""Zote Balloon (3)"",""Grey Prince""],""Dream_Final_Boss"":[""Boss Control/Radiance"",""Boss Control/Radiance Roar/Roar Feathers"",""Boss Control/Radiance/Pt Feather Burst"",""Boss Control/Abyss Pit/Pt Mist"",""Boss Control/Abyss Pit/Pt Surface""],""Room_Final_Boss_Core"":[""Boss Control/Hollow Knight Boss""],""GG_Atrium"":[""GG_Challenge_Door (1)/Door/Lock Break/lock burst"",""gg_atrium_hidden_path/gg_roof open_effect/wispy smoke object (2)""],""GG_Hollow_Knight"":[""Battle Scene/HK Prime""],""GG_Lurker"":[""Lurker Control/Pale Lurker"",""Lurker Control/Pale Lurker/Slash Ball""],""GG_Nailmasters"":[""Brothers/Oro"",""Brothers/Mato""],""GG_Painter"":[""Battle Scene/Sheo Boss""],""GG_Pipeway"":[""Fat Fluke""],""GG_Radiance"":[""Boss Control/Absolute Radiance""],""GG_Sly"":[""Battle Scene/Sly Boss""],""GG_Mighty_Zote"":[""Zote Turret"",""Battle Control/First Zote/Zote Boss"",""Battle Control/Zote Balloon Ordeal"",""Battle Control/Zote Salubra"",""Battle Control/Zote Thwomp"",""Battle Control/Zote Fluke"",""Battle Control/Fat Zotes/Zote Crew Fat (1)"",""Battle Control/Zote Thwomp/Pt Break"",""Battle Control/Zotelings/Ordeal Zoteling"",""Battle Control/Tall Zotes/Zote Crew Tall"",""Battle Control/Dormant Warriors/Zote Crew Normal (1)"",""Battle Control/Music""],""GG_Brooding_Mawlek_V"":[""Battle Scene/Tiso Boss"",""Battle Scene/Tiso Boss/Corpse""],""GG_Nosk_Hornet"":[""Battle Scene/Hornet Nosk""],""Ruins1_23"":[""Mage Knight""],""Deepnest_East_06"":[""Giant Hopper (2)""],""Abyss_17"":[""Lesser Mawlek""],""Dream_04_White_Defender"":[""White Defender""],""GG_Broken_Vessel"":[""Infected Knight""],""GG_Nosk"":[""Mimic Spider""],""GG_Soul_Tyrant"":[""Dream Mage Lord Phase2""],""GG_Uumuu"":[""Mega Jellyfish GG""]}}";

        public override string GetVersion() => Version;

        public PreloadCacheMod()
        {
            try
            {
                Log($"PreloadCacheMod: Constructor v{Version} called.");

                var assembly = Assembly.Load("Assembly-CSharp");
                if (assembly == null) { Log("Failed to load Assembly-CSharp!"); return; }

                Type preloaderType = assembly.GetType("Modding.Preloader");
                if (preloaderType == null) { Log("Failed to find Modding.Preloader type!"); return; }

                var preloadMethod = preloaderType.GetMethod("Preload",
                    BindingFlags.Public | BindingFlags.Instance);
                if (preloadMethod == null) { Log("Failed to find Preload method!"); return; }

                var parameters = preloadMethod.GetParameters();
                bool isStatic = preloadMethod.IsStatic;
                Log($"Preload found: IsStatic={isStatic}, {parameters.Length} parameters.");

                // 关键：委托参数数量 = 方法参数数量 + (是否为实例方法 ? 1 : 0)
                if (isStatic)
                {
                    if (parameters.Length == 1)
                        _preloadHook = new Hook(preloadMethod, (Func<object, IEnumerator>)PreloadReplacement_1Arg);
                    else if (parameters.Length == 2)
                        _preloadHook = new Hook(preloadMethod, (Func<object, object, IEnumerator>)PreloadReplacement_2Args);
                    else if (parameters.Length == 3)
                        _preloadHook = new Hook(preloadMethod, (Func<object, object, object, IEnumerator>)PreloadReplacement_3Args);
                    else if (parameters.Length == 4)
                        _preloadHook = new Hook(preloadMethod, (Func<object, object, object, object, IEnumerator>)PreloadReplacement_4Args);
                    else
                    {
                        Log($"Unsupported static param count: {parameters.Length}");
                        return;
                    }
                }
                else
                {
                    if (parameters.Length == 1)
                        _preloadHook = new Hook(preloadMethod, (Func<object, IEnumerator>)PreloadReplacement_1Arg);
                    else if (parameters.Length == 2)
                        _preloadHook = new Hook(preloadMethod, (Func<object, object, IEnumerator>)PreloadReplacement_2Args);
                    else if (parameters.Length == 3)
                        // 实例方法有 3 个参数，加上 this 共 4 个，必须用 4 参数委托
                        _preloadHook = new Hook(preloadMethod, (Func<object, object, object, object, IEnumerator>)PreloadReplacement_4Args);
                    else if (parameters.Length == 4)
                        _preloadHook = new Hook(preloadMethod, (Func<object, object, object, object, IEnumerator>)PreloadReplacement_4Args);
                    else
                    {
                        Log($"Unsupported instance param count: {parameters.Length}");
                        return;
                    }
                }

                Log("Hook installed (ctor).");
            }
            catch (Exception e)
            {
                Log($"Hook install failed: {e}");
            }
        }

        public override void Initialize()
        {
            Log("Initialize() called.");
        }

        // ---------- 委托重载 ----------
        private IEnumerator PreloadReplacement_1Arg(object a0) =>
            PreloadReplacement_Internal(a0, null, null, null);

        private IEnumerator PreloadReplacement_2Args(object a0, object a1) =>
            PreloadReplacement_Internal(a0, a1, null, null);

        private IEnumerator PreloadReplacement_3Args(object a0, object a1, object a2) =>
            PreloadReplacement_Internal(a0, a1, a2, null);

        private IEnumerator PreloadReplacement_4Args(object a0, object a1, object a2, object a3) =>
            PreloadReplacement_Internal(a0, a1, a2, a3);

        // ---------- 核心逻辑 ----------
        private IEnumerator PreloadReplacement_Internal(object instance, object arg1, object arg2, object arg3)
        {
            string persistentPath = Application.persistentDataPath;
            string cachePath = Path.Combine(persistentPath, CacheDirName);
            string bundlePath = Path.Combine(cachePath, BundleFileName);
            string manifestPath = Path.Combine(cachePath, ManifestFileName);

            try { Directory.CreateDirectory(cachePath); } catch { }

            if (File.Exists(bundlePath) && File.Exists(manifestPath))
            {
                Log("Cache found. Loading from file.");
                yield return InvokeDoPreloadAssetBundle(instance, bundlePath);
                yield break;
            }

            string gameDir = GetFieldValue<string>(instance, "_gameDir");
            if (string.IsNullOrEmpty(gameDir))
            {
                gameDir = persistentPath;
                Log($"gameDir fallback: {gameDir}");
            }
            Log($"gameDir: {gameDir}");

            var candidates = BuildJsonCandidates(instance, arg1);

            bool success = false;
            string lastError = null;
            foreach (var cand in candidates)
            {
                string preview = cand.Json.Length > 160 ? cand.Json.Substring(0, 160) + "..." : cand.Json;
                Log($"[Candidate:{cand.Source}] length={cand.Json.Length} preview={preview}");

                string err;
                if (RunExportBatched(cand.Json, gameDir, cachePath, bundlePath, out err))
                {
                    success = true;
                    Log($"[Candidate:{cand.Source}] SUCCESS.");
                    break;
                }
                Log($"[Candidate:{cand.Source}] failed: {(err ?? "unknown")}");
                lastError = err;
            }

            if (success && File.Exists(bundlePath))
            {
                try { File.WriteAllText(manifestPath, "{\"version\":\"" + Version + "\"}"); }
                catch (Exception e) { Log("manifest write failed: " + e.Message); }

                Log("Loading bundle from file...");
                yield return InvokeDoPreloadAssetBundle(instance, bundlePath);
                yield break;
            }

            Log("All candidates failed (" + (lastError ?? "n/a") + "). Falling back to original Preload.");
            if (_preloadHook != null)
            {
                try { _preloadHook.Undo(); Log("Hook removed for fallback."); }
                catch (Exception e) { Log($"Hook undo failed: {e.Message}"); }
            }
            yield return InvokeOriginalPreload(instance, arg1, arg2, arg3);
        }

        // ---------- 候选 JSON 构建 ----------
        private class Candidate
        {
            public string Source;
            public string Json;
        }

        private List<Candidate> BuildJsonCandidates(object instance, object arg1)
        {
            var list = new List<Candidate>();
            var seen = new HashSet<string>();

            System.Action<string, string> add = (source, json) =>
            {
                if (string.IsNullOrEmpty(json)) return;
                if (!seen.Add(json)) { Log($"Candidate '{source}' duplicates an earlier one, skipped."); return; }
                list.Add(new Candidate { Source = source, Json = json });
            };

            string debugDir = Path.Combine(Application.persistentDataPath, CacheDirName);
            try { Directory.CreateDirectory(debugDir); } catch { }

            string fieldJson = GetFieldValue<string>(instance, "_preloadJson");
            if (!string.IsNullOrEmpty(fieldJson))
            {
                Log($"Got preloadJson from _preloadJson field, length={fieldJson.Length}");
                DumpDebug(debugDir, "preload_debug_1_field.json", fieldJson);
                add("field", fieldJson);
            }

            string argJson = TrySerializeNewtonsoft(arg1);
            if (!string.IsNullOrEmpty(argJson))
            {
                Log($"Serialized arg1 via Newtonsoft, length={argJson.Length}");
                DumpDebug(debugDir, "preload_debug_2_arg1.json", argJson);
                add("arg1", argJson);
            }

            string manualJson = TrySerializeManual(arg1);
            if (!string.IsNullOrEmpty(manualJson))
            {
                Log($"Serialized arg1 manually, length={manualJson.Length}");
                DumpDebug(debugDir, "preload_debug_3_arg1_manual.json", manualJson);
                add("arg1-manual", manualJson);
            }

            add("hardcoded-unwrapped", PreloadJsonUnwrapped);
            add("hardcoded-wrapped", PreloadJsonWrapped);

            return list;
        }

        private bool RunExportBatched(string preloadJson, string gameDir, string cachePath, string bundlePath, out string error)
        {
            error = null;
            try
            {
                var task = Task.Run(() =>
                {
                    IntPtr errorPtr = IntPtr.Zero;
                    int bundleSize = 0;
                    IntPtr bundleDataPtr = IntPtr.Zero;
                    CStats stats = new CStats();

                    try
                    {
                        export_batched(
                            "modding_api_asset_bundle",
                            gameDir,
                            preloadJson,
                            cachePath,
                            1,
                            out errorPtr,
                            out bundleSize,
                            out bundleDataPtr,
                            out stats,
                            null,
                            0,
                            1
                        );

                        if (errorPtr != IntPtr.Zero)
                        {
                            string err = Marshal.PtrToStringAnsi(errorPtr) ?? "unknown error";
                            free_str(errorPtr);
                            return Tuple.Create(false, err);
                        }

                        Log($"export_batched returned. bundle_size={bundleSize}, stats: {stats.obj_count_before}->{stats.obj_count_after}");

                        if (bundleDataPtr != IntPtr.Zero && bundleSize > 0)
                        {
                            Log("Writing bundle from memory...");
                            byte[] data = new byte[bundleSize];
                            Marshal.Copy(bundleDataPtr, data, 0, bundleSize);
                            File.WriteAllBytes(bundlePath, data);
                            free_array(bundleDataPtr);
                        }

                        bool ok = File.Exists(bundlePath);
                        return Tuple.Create(ok, ok ? null : "no error ptr but no bundle produced");
                    }
                    catch (Exception ex)
                    {
                        return Tuple.Create(false, ex.GetType().Name + ": " + ex.Message);
                    }
                });

                bool completed = task.Wait(TimeSpan.FromSeconds(60));
                if (!completed) { error = "timeout after 60s"; return false; }
                error = task.Result.Item2;
                return task.Result.Item1;
            }
            catch (Exception ex)
            {
                error = ex.GetType().Name + ": " + ex.Message;
                return false;
            }
        }

        private string TrySerializeNewtonsoft(object arg1)
        {
            if (arg1 == null) return null;
            try
            {
                var jsonConvertType = Type.GetType("Newtonsoft.Json.JsonConvert");
                if (jsonConvertType == null) { Log("Newtonsoft.Json.JsonConvert type not found."); return null; }

                var method = jsonConvertType.GetMethod("SerializeObject", new Type[] { typeof(object) });
                if (method == null) { Log("SerializeObject method not found."); return null; }

                string result = method.Invoke(null, new object[] { arg1 }) as string;
                if (string.IsNullOrEmpty(result)) { Log("SerializeObject returned empty."); return null; }
                return result;
            }
            catch (Exception e)
            {
                Log($"Newtonsoft serialization failed: {e.Message}");
                return null;
            }
        }

        private string TrySerializeManual(object arg1)
        {
            try
            {
                if (arg1 == null) return null;
                var dict = arg1 as IDictionary;
                if (dict == null) { Log($"arg1 is not IDictionary (actual: {arg1.GetType().FullName})"); return null; }

                var sb = new System.Text.StringBuilder();
                sb.Append("{");
                bool first = true;
                foreach (DictionaryEntry entry in dict)
                {
                    if (!first) sb.Append(",");
                    first = false;
                    sb.Append("\"").Append(EscapeString(Convert.ToString(entry.Key))).Append("\":");

                    if (entry.Value is string)
                    {
                        sb.Append("\"").Append(EscapeString((string)entry.Value)).Append("\"");
                    }
                    else
                    {
                        var items = entry.Value as IEnumerable;
                        sb.Append("[");
                        bool firstItem = true;
                        if (items != null)
                        {
                            foreach (var item in items)
                            {
                                if (!firstItem) sb.Append(",");
                                firstItem = false;
                                sb.Append("\"").Append(EscapeString(Convert.ToString(item))).Append("\"");
                            }
                        }
                        sb.Append("]");
                    }
                }
                sb.Append("}");
                return sb.ToString();
            }
            catch (Exception e)
            {
                Log($"Manual serialization failed: {e.Message}");
                return null;
            }
        }

        private static string EscapeString(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\", "\\\\")
                    .Replace("\"", "\\\"")
                    .Replace("\n", "\\n")
                    .Replace("\r", "\\r")
                    .Replace("\t", "\\t");
        }

        private void DumpDebug(string dir, string fileName, string content)
        {
            try { File.WriteAllText(Path.Combine(dir, fileName), content); }
            catch (Exception e) { Log("DumpDebug failed: " + e.Message); }
        }

        private IEnumerator InvokeOriginalPreload(object instance, object arg1, object arg2, object arg3)
        {
            var m = instance.GetType().GetMethod("Preload",
                BindingFlags.Public | BindingFlags.Instance);
            if (m != null)
            {
                Log($"Calling original Preload with 3 args.");
                yield return (IEnumerator)m.Invoke(instance, new object[] { arg1, arg2, arg3 });
            }
            else
            {
                Log("Cannot invoke original Preload.");
            }
        }

        private IEnumerator InvokeDoPreloadAssetBundle(object instance, string bundlePath)
        {
            var m = instance.GetType().GetMethod("DoPreloadAssetBundle",
                BindingFlags.NonPublic | BindingFlags.Instance);
            if (m == null)
            {
                Log("DoPreloadAssetBundle not found!");
                yield break;
            }

            AssetBundle bundle = AssetBundle.LoadFromFile(bundlePath);
            if (bundle == null)
            {
                Log("LoadFromFile failed!");
                yield break;
            }

            Log("Bundle loaded, calling DoPreloadAssetBundle...");
            yield return (IEnumerator)m.Invoke(instance, new object[] { bundle, null });
        }

        private T GetFieldValue<T>(object obj, string fieldName)
        {
            if (obj == null) return default(T);
            var f = obj.GetType().GetField(fieldName,
                BindingFlags.NonPublic | BindingFlags.Instance |
                BindingFlags.Public | BindingFlags.Static);
            if (f == null) return default(T);
            try
            {
                var v = f.GetValue(f.IsStatic ? null : obj);
                return v == null ? default(T) : (T)v;
            }
            catch { return default(T); }
        }

        // ---------- DllImport ----------
        [StructLayout(LayoutKind.Sequential)]
        private struct CStats
        {
            public int obj_count_before;
            public int obj_count_after;
        }

        [DllImport("unityscenerepacker", CallingConvention = CallingConvention.Cdecl)]
        private static extern void export_batched(
            [MarshalAs(UnmanagedType.LPUTF8Str)] string name,
            [MarshalAs(UnmanagedType.LPUTF8Str)] string game_dir,
            [MarshalAs(UnmanagedType.LPUTF8Str)] string preload_json,
            [MarshalAs(UnmanagedType.LPUTF8Str)] string cache_dir,
            int resume,
            out IntPtr error,
            out int bundle_size,
            out IntPtr bundle_data,
            out CStats stats_ret,
            byte[] mb_typetree_export,
            int mb_typetree_len,
            int mode
        );

        [DllImport("unityscenerepacker", CallingConvention = CallingConvention.Cdecl)]
        private static extern void free_str(IntPtr ptr);

        [DllImport("unityscenerepacker", CallingConvention = CallingConvention.Cdecl)]
        private static extern void free_array(IntPtr ptr);
    }
}