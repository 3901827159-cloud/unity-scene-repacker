using System;
using System.IO;
using System.Collections;
using System.Reflection;
using System.Runtime.InteropServices;
using UnityEngine;
using MonoMod.RuntimeDetour;

namespace PreloadCacheMod
{
    public class PreloadCacheMod : Modding.Mod
    {
        private static Hook _preloadHook;
        private const string CacheDirName = "ModdingApi.PreloadCache";
        private const string BundleFileName = "final.unity3d";
        private const string ManifestFileName = "manifest.json";
        private const string Version = "1.1.5";

        public override string GetVersion() => Version;

        public PreloadCacheMod()
        {
            try
            {
                Log($"PreloadCacheMod: Constructor v{Version} called.");

                var assembly = Assembly.Load("Assembly-CSharp");
                if (assembly == null) { Log("Failed to load Assembly-CSharp!"); return; }

                Type preloaderType = assembly.GetType("Modding.Preloader");
                if (preloaderType == null) { Log("Failed to find Modding.Preloader type!"); return; }

                var preloadMethod = preloaderType.GetMethod("Preload",
                    BindingFlags.Public | BindingFlags.Instance);
                if (preloadMethod == null) { Log("Failed to find Preload method!"); return; }

                var parameters = preloadMethod.GetParameters();
                Log($"Preload has {parameters.Length} parameters.");

                // 关键修复：Hook 期望的参数数量 = this + 方法参数数量
                // 对于 3 个参数的方法，委托参数数量应为 4 (this + 3)
                if (parameters.Length == 1)
                    _preloadHook = new Hook(preloadMethod, (Func<object, IEnumerator>)PreloadReplacement_1Arg);
                else if (parameters.Length == 2)
                    _preloadHook = new Hook(preloadMethod, (Func<object, object, IEnumerator>)PreloadReplacement_2Args);
                else if (parameters.Length == 3)
                    _preloadHook = new Hook(preloadMethod, (Func<object, object, object, object, IEnumerator>)PreloadReplacement_4Args);
                else if (parameters.Length == 4)
                    _preloadHook = new Hook(preloadMethod, (Func<object, object, object, object, IEnumerator>)PreloadReplacement_4Args);
                else
                {
                    Log($"Unsupported param count: {parameters.Length}");
                    return;
                }

                Log("Hook installed (ctor).");
            }
            catch (Exception e)
            {
                Log($"Hook install failed: {e.Message}");
            }
        }

        public override void Initialize()
        {
            Log("Initialize() called.");
        }

        // ---------- 不同参数数量的重载 ----------
        private IEnumerator PreloadReplacement_1Arg(object instance) =>
            PreloadReplacement_Internal(instance, null, null, null);

        private IEnumerator PreloadReplacement_2Args(object instance, object arg1) =>
            PreloadReplacement_Internal(instance, arg1, null, null);

        private IEnumerator PreloadReplacement_3Args(object instance, object arg1, object arg2) =>
            PreloadReplacement_Internal(instance, arg1, arg2, null);

        private IEnumerator PreloadReplacement_4Args(object instance, object arg1, object arg2, object arg3) =>
            PreloadReplacement_Internal(instance, arg1, arg2, arg3);

        // ---------- 核心逻辑（已修复 try-catch 与 yield return 冲突）----------
        private IEnumerator PreloadReplacement_Internal(object instance, object arg1, object arg2, object arg3)
        {
            bool cacheExists = false;
            bool buildSuccess = false;
            bool fallback = false;
            string bundlePath = null;
            string cachePath = null;

            // ---------- 第1步：检查缓存 ----------
            string persistentPath = Application.persistentDataPath;
            cachePath = Path.Combine(persistentPath, CacheDirName);
            bundlePath = Path.Combine(cachePath, BundleFileName);
            string manifestPath = Path.Combine(cachePath, ManifestFileName);

            if (File.Exists(bundlePath) && File.Exists(manifestPath))
            {
                Log("Cache found. Loading from file.");
                cacheExists = true;
            }
            else
            {
                Log("No cache. Building via export_batched...");

                // ---------- 第2步：准备数据 ----------
                string gameDir = GetFieldValue<string>(instance, "_gameDir");
                if (string.IsNullOrEmpty(gameDir))
                {
                    gameDir = Application.persistentDataPath;
                    Log($"gameDir fallback: {gameDir}");
                }
                Log($"gameDir: {gameDir}");

                string preloadJson = GetPreloadJson(instance, arg1, arg2, arg3);
                if (string.IsNullOrEmpty(preloadJson))
                {
                    Log("Failed to get preloadJson, falling back to original.");
                    fallback = true;
                }
                else
                {
                    Log($"preloadJson length: {preloadJson.Length}");
                    Directory.CreateDirectory(cachePath);

                    // ---------- 第3步：调用 export_batched ----------
                    IntPtr errorPtr = IntPtr.Zero;
                    int bundleSize = 0;
                    IntPtr bundleDataPtr = IntPtr.Zero;
                    CStats stats = new CStats();

                    try
                    {
                        Log("Calling export_batched...");

                        export_batched(
                            "modding_api_asset_bundle",
                            gameDir,
                            preloadJson,
                            cachePath,
                            1,
                            out errorPtr,
                            out bundleSize,
                            out bundleDataPtr,
                            out stats,
                            null,
                            0,
                            1
                        );

                        if (errorPtr != IntPtr.Zero)
                        {
                            string err = Marshal.PtrToStringAnsi(errorPtr);
                            Log($"export_batched error: {err}");
                            free_str(errorPtr);
                        }
                        else
                        {
                            Log($"export_batched succeeded. bundle_size: {bundleSize}");

                            if (File.Exists(bundlePath))
                            {
                                Log($"Bundle built at {bundlePath}");
                                buildSuccess = true;
                            }
                            else if (bundleDataPtr != IntPtr.Zero && bundleSize > 0)
                            {
                                Log("Writing bundle from memory...");
                                byte[] data = new byte[bundleSize];
                                Marshal.Copy(bundleDataPtr, data, 0, bundleSize);
                                File.WriteAllBytes(bundlePath, data);
                                buildSuccess = true;
                            }
                            else
                            {
                                Log("Bundle file not found and no memory data.");
                            }

                            if (bundleDataPtr != IntPtr.Zero)
                                free_array(bundleDataPtr);
                        }
                    }
                    catch (DllNotFoundException e)
                    {
                        Log($"DllNotFoundException: {e.Message}");
                    }
                    catch (EntryPointNotFoundException e)
                    {
                        Log($"EntryPointNotFoundException: {e.Message}");
                    }
                    catch (Exception e)
                    {
                        Log($"export_batched exception: {e.GetType().Name}: {e.Message}");
                    }
                }
            }

            // ---------- 第4步：根据结果执行 ----------
            if (cacheExists)
            {
                yield return InvokeDoPreloadAssetBundle(instance, bundlePath);
                yield break;
            }

            if (fallback || !buildSuccess)
            {
                Log("Falling back to original Preload.");
                yield return InvokeOriginalPreload(instance, arg1, arg2, arg3);
                yield break;
            }

            if (buildSuccess)
            {
                Log("Loading bundle from file...");
                yield return InvokeDoPreloadAssetBundle(instance, bundlePath);
                yield break;
            }

            // 保险回退
            Log("Unhandled case, falling back to original Preload.");
            yield return InvokeOriginalPreload(instance, arg1, arg2, arg3);
        }

        // ---------- 辅助方法 ----------
        private string GetPreloadJson(object instance, object arg1, object arg2, object arg3)
        {
            string json = GetFieldValue<string>(instance, "_preloadJson");
            if (!string.IsNullOrEmpty(json)) return json;

            if (arg1 != null)
            {
                try
                {
                    var nt = Type.GetType("Newtonsoft.Json.JsonConvert");
                    if (nt != null)
                    {
                        var m = nt.GetMethod("SerializeObject", new Type[] { typeof(object) });
                        if (m != null)
                        {
                            var result = m.Invoke(null, new object[] { arg1 });
                            return result?.ToString();
                        }
                    }
                    return arg1.ToString();
                }
                catch { }
            }
            return null;
        }

        private IEnumerator InvokeOriginalPreload(object instance, object arg1, object arg2, object arg3)
        {
            var m = instance.GetType().GetMethod("Preload",
                BindingFlags.Public | BindingFlags.Instance);
            if (m != null)
            {
                var p = m.GetParameters();
                object[] args;
                if (p.Length == 1) args = new object[] { };
                else if (p.Length == 2) args = new object[] { arg1 };
                else if (p.Length == 3) args = new object[] { arg1, arg2 };
                else args = new object[] { arg1, arg2, arg3 };

                Log($"Calling original Preload with {args.Length} args.");
                yield return (IEnumerator)m.Invoke(instance, args);
            }
            else
            {
                Log("Cannot invoke original Preload.");
            }
        }

        private IEnumerator InvokeDoPreloadAssetBundle(object instance, string bundlePath)
        {
            var m = instance.GetType().GetMethod("DoPreloadAssetBundle",
                BindingFlags.NonPublic | BindingFlags.Instance);
            if (m == null)
            {
                Log("DoPreloadAssetBundle not found!");
                yield return InvokeOriginalPreload(instance, null, null, null);
                yield break;
            }

            AssetBundle bundle = AssetBundle.LoadFromFile(bundlePath);
            if (bundle == null)
            {
                Log("LoadFromFile failed!");
                yield return InvokeOriginalPreload(instance, null, null, null);
                yield break;
            }

            Log("Bundle loaded, calling DoPreloadAssetBundle...");
            yield return (IEnumerator)m.Invoke(instance, new object[] { bundle, null });
        }

        private T GetFieldValue<T>(object obj, string fieldName)
        {
            if (obj == null) return default(T);
            var f = obj.GetType().GetField(fieldName,
                BindingFlags.NonPublic | BindingFlags.Instance |
                BindingFlags.Public | BindingFlags.Static);
            if (f == null) return default(T);
            try
            {
                var v = f.GetValue(obj);
                return v == null ? default(T) : (T)v;
            }
            catch { return default(T); }
        }

        // ---------- DllImport（千问最新 ABI）----------
        [StructLayout(LayoutKind.Sequential)]
        private struct CStats
        {
            public int obj_count_before;
            public int obj_count_after;
        }

        [DllImport("unityscenerepacker", CallingConvention = CallingConvention.Cdecl)]
        private static extern void export_batched(
            [MarshalAs(UnmanagedType.LPUTF8Str)] string name,
            [MarshalAs(UnmanagedType.LPUTF8Str)] string game_dir,
            [MarshalAs(UnmanagedType.LPUTF8Str)] string preload_json,
            [MarshalAs(UnmanagedType.LPUTF8Str)] string cache_dir,
            byte resume,
            out IntPtr error,
            out int bundle_size,
            out IntPtr bundle_data,
            out CStats stats_ret,
            byte[] mb_typetree_export,
            int mb_typetree_len,
            byte mode
        );

        [DllImport("unityscenerepacker", CallingConvention = CallingConvention.Cdecl)]
        private static extern void free_str(IntPtr ptr);

        [DllImport("unityscenerepacker", CallingConvention = CallingConvention.Cdecl)]
        private static extern void free_array(IntPtr ptr);
    }
}