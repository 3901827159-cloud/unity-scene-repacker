/// Basic wip format for type tree dumps for a set of assemblies / types
use anyhow::Result;
use elsa::sync::FrozenMap;
use rabex::typetree::TypeTreeNode;

use typetree_generator_api::reconstruct_typetree_node;

/*
 * n_assemblies x
 *  len name
 *  n_types x:
 *    len full_name
 *    n_flat_nodes x:
 *      len type
 *      len name
 *      u8  level
 *      i32 flags
 *
 * FIX(v15): the dump file stores each node as (type, name, level, flags) —
 * verified byte-by-byte against monobehaviour-typetree-dump.lz4
 * (first type "UnityStandardAssets.ImageEffects.BloomOptimized" has
 *  s1='BloomOptimized' s2='Base'). reconstruct_typetree_node() destructures
 * flat nodes as (type, name, ...), so the reader must push them in that
 * order. The previous (name, type) order silently swapped type/name on
 * every MonoBehaviour typetree, which broke PPtr detection
 * (starts_with("PPtr<")) and made EnemyRandomizer crash on Android.
 */
pub fn read(export: &[u8]) -> Result<FrozenMap<(String, String), Box<TypeTreeNode>>> {
    use anyhow::bail;
    use byteorder::{LE, ReadBytesExt};

    fn read_str(reader: &mut impl std::io::Read) -> Result<String> {
        let len = reader.read_u32::<LE>()?;
        let mut data = vec![0; len as usize];
        reader.read_exact(&mut data)?;
        let str = String::from_utf8(data)?;
        Ok(str)
    }

    let export = lz4_flex::decompress_size_prepended(export)?;
    let mut reader = &mut &*export;
    let monobehaviour_type_cache = FrozenMap::default();
    let mut checked_first_type = false;

    let n_assemblies = reader.read_u32::<LE>()?;
    for _ in 0..n_assemblies {
        let assembly_name = read_str(&mut reader)?;
        let n_types = reader.read_u32::<LE>()?;
        for _ in 0..n_types {
            let full_name = read_str(&mut reader)?;
            let n_flat_nodes = reader.read_u32::<LE>()?;
            let mut flat_nodes = Vec::with_capacity(n_flat_nodes as usize);
            for _ in 0..n_flat_nodes {
                let ty = read_str(&mut reader)?;
                let name = read_str(&mut reader)?;
                let level = reader.read_u8()?;
                let flags = reader.read_i32::<LE>()?;
                flat_nodes.push((ty, name, level, flags));
            }

            let node = reconstruct_typetree_node(&flat_nodes);
            if !checked_first_type {
                checked_first_type = true;
                let short_name = full_name.rsplit('.').next().unwrap_or(&full_name);
                if node.m_Type != short_name {
                    bail!(
                        "monobehaviour-typetree-dump format mismatch for {full_name}: \
                         root m_Type is {:?} but expected class short name {short_name:?}. \
                         The dump file likely uses a different field order than expected.",
                        node.m_Type
                    );
                }
            }
            monobehaviour_type_cache.insert((assembly_name.clone(), full_name), Box::new(node));
        }
    }

    Ok(monobehaviour_type_cache)
}
