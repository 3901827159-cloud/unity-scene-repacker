#![allow(clippy::missing_safety_doc)]
use std::ffi::{CStr, CString, c_char, c_int};
use std::io::Cursor;
use std::path::Path;

use anyhow::{Context as _, Result, bail};
use indexmap::IndexMap;
use rabex::objects::ClassId;
use rabex::typetree::TypeTreeProvider as _;
use rabex_env::Environment;
use rabex_env::resolver::GameFiles;
use rabex_env::typetree_generator_cache::TypeTreeGeneratorCache;
use unity_scene_repacker::rabex::files::bundlefile::CompressionType;
use unity_scene_repacker::rabex::tpk::TpkTypeTreeBlob;
use unity_scene_repacker::rabex::typetree::typetree_cache::sync::TypeTreeCache;
use unity_scene_repacker::{
    MonobehaviourTypetreeMode, RepackSettings, Stats, monobehaviour_typetree_export,
};

#[repr(C)]
pub struct CStats {
    pub objects_before: c_int,
    pub objects_after: c_int,
}

enum Mode {
    SceneBundle = 0,
    AssetBundle = 1,
    AssetBundleShallow = 2,
}
impl Mode {
    fn needs_typetree_generator(&self) -> bool {
        matches!(self, Mode::AssetBundle)
    }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn export(
    name: *const c_char,
    game_dir: *const c_char,
    preload_json: *const c_char,
    error: *mut *const c_char,
    bundle_size: *mut c_int,
    bundle_data: *mut *mut u8,
    stats_ret: *mut CStats,
    mb_typetree_export: *const u8,
    mb_typetree_len: c_int,
    mode: u8,
) {
    unsafe {
        let name = CStr::from_ptr(name);
        let game_dir = CStr::from_ptr(game_dir);
        let preload_json = CStr::from_ptr(preload_json);

        let mb_typetree_export = (!mb_typetree_export.is_null())
            .then(|| std::slice::from_raw_parts(mb_typetree_export, mb_typetree_len as usize));

        let result = export_inner(name, game_dir, preload_json, mode, mb_typetree_export);
        match result {
            Ok((stats, data)) => {
                *bundle_size = data.len() as c_int;
                *bundle_data = Box::into_raw(data.into_boxed_slice()).cast();
                *stats_ret = CStats {
                    objects_before: stats.objects_before as c_int,
                    objects_after: stats.objects_after as c_int,
                }
            }
            Err(e) => {
                let error_string = CString::new(e.to_string()).unwrap_or_else(|_| c"".to_owned());
                *error = CString::into_raw(error_string);
                *bundle_size = 0;
                *bundle_data = std::ptr::null_mut();
            }
        }
    }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn free_str(cstr: *mut c_char) {
    unsafe { drop(CString::from_raw(cstr)) };
}

/// Batched variant of `export` (LSCR Layer 1).
///
/// Processes scenes sequentially, spilling trimmed intermediates to
/// `cache_dir`, and supports resuming after interruption via `resume`.
/// Currently only `mode = 1` (AssetBundle) is supported. On success the final
/// bundle bytes are returned exactly like `export` (so existing C# code works
/// unchanged), and the bundle is additionally persisted to
/// `cache_dir/final.unity3d` for future cache-hit loading.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn export_batched(
    name: *const c_char,
    game_dir: *const c_char,
    preload_json: *const c_char,
    cache_dir: *const c_char,
    resume: u8,
    error: *mut *const c_char,
    bundle_size: *mut c_int,
    bundle_data: *mut *mut u8,
    stats_ret: *mut CStats,
    mb_typetree_export: *const u8,
    mb_typetree_len: c_int,
    mode: u8,
) {
    unsafe {
        let name = CStr::from_ptr(name);
        let game_dir = CStr::from_ptr(game_dir);
        let preload_json = CStr::from_ptr(preload_json);
        let cache_dir = CStr::from_ptr(cache_dir);

        let mb_typetree_export = (!mb_typetree_export.is_null())
            .then(|| std::slice::from_raw_parts(mb_typetree_export, mb_typetree_len as usize));

        let result = export_batched_inner(
            name,
            game_dir,
            preload_json,
            cache_dir,
            resume != 0,
            mode,
            mb_typetree_export,
        );
        match result {
            Ok((stats, data)) => {
                *bundle_size = data.len() as c_int;
                *bundle_data = Box::into_raw(data.into_boxed_slice()).cast();
                *stats_ret = CStats {
                    objects_before: stats.objects_before as c_int,
                    objects_after: stats.objects_after as c_int,
                }
            }
            Err(e) => {
                let error_string = CString::new(e.to_string()).unwrap_or_else(|_| c"".to_owned());
                *error = CString::into_raw(error_string);
                *bundle_size = 0;
                *bundle_data = std::ptr::null_mut();
            }
        }
    }
}

#[unsafe(no_mangle)]
pub extern "C" fn free_array(len: c_int, data: *mut u8) {
    unsafe {
        let data = std::ptr::slice_from_raw_parts_mut(data, len as usize);
        drop(Box::from_raw(data))
    };
}

fn make_environment(
    game_dir: &Path,
    needs_typetree_generator: bool,
    mb_typetree_export: Option<&[u8]>,
) -> Result<Environment> {
    let tpk = TypeTreeCache::new(TpkTypeTreeBlob::embedded());
    let game_files = GameFiles::probe(game_dir)?;
    let mut env = Environment::new(game_files, tpk);

    if needs_typetree_generator {
        let unity_version = env.unity_version()?.clone();
        let monobehaviour_typetree_mode = match mb_typetree_export {
            Some(data) => MonobehaviourTypetreeMode::Export(data),
            None => MonobehaviourTypetreeMode::GenerateRuntime,
        };

        let monobehaviour_node = env
            .tpk
            .get_typetree_node(ClassId::MonoBehaviour, &unity_version)
            .unwrap()
            .into_owned();

        env.typetree_generator = match monobehaviour_typetree_mode {
            MonobehaviourTypetreeMode::GenerateRuntime => {
                TypeTreeGeneratorCache::new(unity_version, monobehaviour_node)
            }
            MonobehaviourTypetreeMode::Export(export) => {
                TypeTreeGeneratorCache::prefilled(monobehaviour_typetree_export::read(export)?)
            }
        };
    }

    Ok(env)
}

fn export_inner(
    name: &CStr,
    game_dir: &CStr,
    scene_objects_json: &CStr,
    mode: u8,
    mb_typetree_export: Option<&[u8]>,
) -> Result<(Stats, Vec<u8>)> {
    let name = name.to_str()?;
    let game_dir = Path::new(game_dir.to_str()?);
    let scene_objects = scene_objects_json.to_str()?;
    let mode = match mode {
        0 => Mode::SceneBundle,
        1 => Mode::AssetBundle,
        2 => Mode::AssetBundleShallow,
        _ => bail!("Expected 0=SceneBundle, 1=AssetBundle or 2=AssetBundleShallow, got {mode}"),
    };

    let tpk_raw = TpkTypeTreeBlob::embedded();

    let compression = CompressionType::None;

    let scene_objects: IndexMap<String, Vec<String>> =
        serde_json::from_str(scene_objects).context("error parsing the objects json")?;

    let repack_settings = RepackSettings {
        scene_objects,
        extra_objects: IndexMap::new(),
    };

    let disable = true;

    let mut out = Cursor::new(Vec::new());

    let env = make_environment(game_dir, mode.needs_typetree_generator(), mb_typetree_export)?;
    let unity_version = env.unity_version()?.clone();

    if let Mode::AssetBundleShallow = mode {
        let stats = unity_scene_repacker::pack_to_shallow_asset_bundle(
            &env,
            &mut out,
            name,
            repack_settings,
            compression,
        )?;
        return Ok((stats, out.into_inner()));
    }

    let (mut repack_scenes, extra_objects) = unity_scene_repacker::repack_scenes(
        &env,
        repack_settings,
        disable,
        matches!(mode, Mode::AssetBundle),
    )?;

    let enable_typetree = false; // TODO: make this configurable / infer if necessary

    let stats = match mode {
        Mode::SceneBundle => unity_scene_repacker::pack_to_scene_bundle(
            &mut out,
            name,
            &tpk_raw,
            &env.tpk,
            &unity_version,
            repack_scenes.as_mut_slice(),
            compression,
        )
        .context("trying to repack bundle")?,
        Mode::AssetBundle => unity_scene_repacker::pack_to_asset_bundle(
            &env,
            &mut out,
            name,
            &tpk_raw,
            repack_scenes,
            extra_objects,
            compression,
            enable_typetree,
        )?,
        Mode::AssetBundleShallow => unreachable!(),
    };

    Ok((stats, out.into_inner()))
}

fn export_batched_inner(
    name: &CStr,
    game_dir: &CStr,
    scene_objects_json: &CStr,
    cache_dir: &CStr,
    resume: bool,
    mode: u8,
    mb_typetree_export: Option<&[u8]>,
) -> Result<(Stats, Vec<u8>)> {
    eprintln!("[LSCR] export_batched: v16 missing-path-report build (unresolved paths are written to cache_dir/missing_paths.json)");
    let name = name.to_str()?;
    let game_dir = Path::new(game_dir.to_str()?);
    let cache_dir = Path::new(cache_dir.to_str()?);
    let scene_objects = scene_objects_json.to_str()?;
    match mode {
        1 => {}
        m => bail!("export_batched currently only supports mode=1 (AssetBundle), got {m}"),
    }

    let tpk_raw = TpkTypeTreeBlob::embedded();

    let scene_objects: IndexMap<String, Vec<String>> =
        serde_json::from_str(scene_objects).context("error parsing the objects json")?;

    let repack_settings = RepackSettings {
        scene_objects,
        extra_objects: IndexMap::new(),
    };

    let env = make_environment(game_dir, true, mb_typetree_export)?;

    // Phase 1: sequential per-scene repack with disk spill + manifest.
    // prepare_scripts=true, disable_roots=true — same as the one-shot
    // AssetBundle path in `export_inner`.
    unity_scene_repacker::repack_scenes_batched(
        &env,
        repack_settings,
        true,
        true,
        &tpk_raw,
        cache_dir,
        name,
        resume,
    )?;

    // Phase 2: merge intermediates into the final AssetBundle.
    let compression = CompressionType::None;
    let enable_typetree = false;
    let mut out = Cursor::new(Vec::new());
    let stats = unity_scene_repacker::pack_to_asset_bundle_from_cache(
        &env,
        &mut out,
        name,
        &tpk_raw,
        cache_dir,
        compression,
        enable_typetree,
    )?;

    let bytes = out.into_inner();

    // Surface the missing-path report (if any) to stderr for adb logcat.
    let missing_report_path = cache_dir.join("missing_paths.json");
    if missing_report_path.exists() {
        eprintln!(
            "[LSCR] warning: some requested object paths were not found; see {}",
            missing_report_path.display()
        );
    }

    // Persist the final bundle next to the manifest so a future Layer 2
    // cache-hit path can `LoadFromFile` without rerunning the repack.
    let final_path =
        cache_dir.join(unity_scene_repacker::batched_cache::FINAL_BUNDLE_FILE);
    if let Err(e) = std::fs::write(&final_path, &bytes) {
        eprintln!(
            "could not persist final bundle to {}: {e}",
            final_path.display()
        );
    }

    Ok((stats, bytes))
}
